import { Link, Navigate, useLocation } from "react-router-dom";
import { Image } from "react-bootstrap";
import server_down from "./assets/images/undraw_server_down_s-4-lk.svg";
import { FaAssistiveListeningSystems, FaHome, FaServer } from "react-icons/fa";
import { UserState } from "./items/user";
import { useQuery } from "react-query";
import { axiosInstance } from "./utils/authcontext";
import { Loading } from "bsoft-react-ui";

export enum Role{
    Admin, Visitor, Worker, Client, None
}

const titleToRole = (title: string): Role =>{
    switch(title){
        case "admin":
            return Role.Admin;
        case "visitor":
            return Role.Visitor;
        case  "worker":
            return Role.Worker;
        case "client":
            return Role.Client;
    }
    return Role.None;
}

interface PrivateRouteProps{
    roles: Role[],
    element: JSX.Element
}

export const PrivateRoute = ({element, roles}: PrivateRouteProps) =>{
    let isAuthenticated = false;
    const location = useLocation();
    const prevRoute = location.pathname.length >  1 ? location.pathname.replaceAll("/", "_").substring(1) : "";

    const initQuery = useQuery({
        queryKey: ['user'],
        queryFn: () => axiosInstance.get<UserState>('/user')
    });

    if(initQuery.isLoading){
        return (<Loading />);
    }else if(!initQuery.data?.data){
        return (<Navigate to={`/signin/${prevRoute}`} />);
    }

    const userState = initQuery.data?.data as UserState;

    if(userState?.user?.type){
        isAuthenticated = roles.includes(titleToRole(userState.user?.type));
    }else if(userState.user && roles.includes(Role.None)){
        isAuthenticated = true;
    }
    
    return isAuthenticated ? element : (
        <div style={{display: "flex", width: "100dvw", height:"100dvh", justifyContent: "center", alignItems: "center", flexDirection:"column"}}>
            <Image src={server_down} style={{minWidth:  "200px", maxWidth:"500px"}}/>
            <div className="mt-3 mx-3 text-center" style={{color: "gray", fontSize:"24px", maxWidth: "800px"}}><FaServer size={30} /> Sorry you are not authorized to view this page. you must be an admin, client or worker to view this page <FaAssistiveListeningSystems size={30} /></div>
            <Link to={"/"} className="btn btn-outline-primary mt-3" style={{borderRadius: "20px"}}><FaHome size={20} /> to Homepage</Link> 
        </div>
    );
}