interface ErrorResponse{
    message: string;
}

export type{ ErrorResponse };