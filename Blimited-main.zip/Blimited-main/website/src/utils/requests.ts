interface SignUpRequest{
    fname: string, username: string, phone: string, email:string, password: string, repassword: string
}

interface LoginRequest{
    email: string, password: string
}

export type { SignUpRequest, LoginRequest }