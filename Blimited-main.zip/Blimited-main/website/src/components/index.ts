import Footer from "./footer";
import Header from "./header";
import Login from "./login";
import SignUp from "./signup";

export { Footer, Header, Login, SignUp }