import { useState } from "react";
import { Button, Form } from "react-bootstrap"
import { SignUpRequest } from "../utils/requests";
import { User } from "../items/user";
import { useNavigate } from "react-router-dom";
import { useMutation } from "react-query";
import { axiosInstance } from "../utils/authcontext";
import { CircleLoading } from "bsoft-react-ui";

const SignUp = () =>{
    const navigate = useNavigate();
    const [signupDetails, setSignupDetails] = useState<SignUpRequest>({fname:"", username: "", phone: "", email: "", password: "", repassword: ""});

    const signupMutation = useMutation({
        mutationKey: ["user-signup"],
        mutationFn: (signupDetails: SignUpRequest) => axiosInstance.post<User>("/users", signupDetails),
        onSuccess: ()=>{
            navigate("/");
        },
        onError(error) {
            alert(JSON.stringify(error));
        },
    });

    const signupChange = (event: React.ChangeEvent<HTMLInputElement>) =>{
        let input = event.currentTarget;
        switch(input.id){
            case "fname":
                setSignupDetails({...signupDetails, fname: input.value});
                break;
            case "username":
                setSignupDetails({...signupDetails, username: input.value});
                break;
            case "phone":
                setSignupDetails({...signupDetails, phone: input.value});
                break;
            case "email":
                setSignupDetails({...signupDetails, email: input.value});
                break;
            case "password":
                setSignupDetails({...signupDetails, password: input.value});
                break;
            case "repassword":
                setSignupDetails({...signupDetails, repassword: input.value});
                break;
        }
    }

    const handleSubmit = (event: React.UIEvent<HTMLFormElement>) => {
        event.preventDefault();
        if(signupDetails.password === signupDetails.repassword){
            signupMutation.mutate(signupDetails);
        }else{
            alert("Password and Confirm Password mismatch");
        }
    };

    return (
        <Form className="slidin form" id="signup" onSubmit={handleSubmit}>
            <Form.Group controlId="fname">
                <Form.Label className="form-label">Full Name</Form.Label>
                <Form.Control onChange={signupChange} className="form-input" value={signupDetails.fname}  required type="text" placeholder='Enter your Full Name. Eg John Smith'/>
            </Form.Group>
            <Form.Group controlId="username">
                <Form.Label className="form-label">Username</Form.Label>
                <Form.Control onChange={signupChange} className="form-input" value={signupDetails.username} required type="text" placeholder='Enter a unique username eg bobby18'/>
            </Form.Group>
            <Form.Group controlId="email">
                <Form.Label className="form-label">Email</Form.Label>
                <Form.Control onChange={signupChange} className="form-input" value={signupDetails.email} required type="email" placeholder='Enter your Email'/>
            </Form.Group>
            <Form.Group controlId="phone">
                <Form.Label className="form-label">Phone</Form.Label>
                <Form.Control onChange={signupChange} className="form-input" value={signupDetails.phone}  required type="phone" placeholder='Enter your phone number'/>
            </Form.Group>
            <Form.Group controlId="password">
                <Form.Label className="form-label">Password</Form.Label>
                <Form.Control onChange={signupChange} className="form-input" value={signupDetails.password} required type="password" placeholder="Enter your Password" />
            </Form.Group>
            <Form.Group controlId="repassword">
                <Form.Label className="form-label">Confirm Password</Form.Label>
                <Form.Control onChange={signupChange} className="form-input" value={signupDetails.repassword} required type="password" placeholder="Confirm your Password" />
            </Form.Group>
            <Button  variant="primary" className='options-btn' type="submit">
                { signupMutation.isLoading && ( <CircleLoading message={"Submitting ..."}/> ) }
                { !signupMutation.isLoading && "Submit" }
            </Button>
        </Form>
    )
}

export default SignUp;