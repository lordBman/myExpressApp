import { Container, Nav, NavDropdown, Navbar, NavbarBrand } from "react-bootstrap";
import { Link } from "react-router-dom";
import "../assets/styles/header.scss";
import { useEffect, useState } from "react";
import { User } from "../items/user";
import { FaBell, FaCogs } from "react-icons/fa";
import profile from "../assets/images/profile.png";
import { useMutation, useQuery, useQueryClient } from "react-query";
import { axiosInstance } from "../utils/authcontext";

const Header = (props:{active?: string}) =>{
    const [active, setActive] = useState(props.active || "home");
    const queryClient = useQueryClient();

    const initQuery = useQuery({
        queryKey: ['user'],
        queryFn: () => axiosInstance.get<User>('/'),
    });

    const logoutMutation = useMutation({
        mutationKey: ['user'],
        mutationFn: () => axiosInstance.get('/logout'),
        onSuccess: () => {
            queryClient.invalidateQueries("user");
        },
        onError: ((error)=> alert(error))
    });

    const handleClickScroll = (id: string) =>{
        const element = document.getElementById(id);
        if(element){
            element.scrollIntoView({behavior: "smooth"});
            setActive(id);
        }
    }

    useEffect(()=>{
        window.addEventListener("scroll", function (){
            let navbar = document.getElementById("navbar");
            let up_button_element = document.getElementById("up-btn");
			if(navbar){
				if (document.body.scrollTop > 80 || document.documentElement.scrollTop > 80) {
                    navbar.classList.add("navbar-bg-grey");
                    navbar.classList.add("shadow");
                    if(up_button_element){
                        up_button_element.style.display = "inline";
                    }
                } else {
                    navbar.classList.remove("navbar-bg-grey");
                    navbar.classList.remove("shadow");
                    if(up_button_element){
                        up_button_element.style.display = "none";
                    }
                }

                let current:string = "";
                let sections = document.querySelectorAll("section");
                sections.forEach((section) => {
                    const sectionTop = section.offsetTop;
                    if (this.scrollY >= sectionTop - 60) {
                        let init = section.id;
                        current = init == null ? "" : init;
                    }
                });

                if(current !== ""){
                    setActive(current);
                }
			}
		});
    },[]);

    const signout = () => logoutMutation.mutate();

    const scrollToHome = () => handleClickScroll("home");
    const scrollToAbout = () => handleClickScroll("about");
    const scrollToServices = () => handleClickScroll("services");
    const scrollToUsers = () => handleClickScroll("users");
    const scrollToDownloads = () => handleClickScroll("downloads");
    const scrollToProjects = () => handleClickScroll("projects");
    const scrollToCOntacts = () => handleClickScroll("contacts");

    return (
        <Navbar className={"navbar-light fixed-top"} id="navbar">
            <Container fluid className="px-md-3 px-lg-5">
                <NavbarBrand className="nav-brand">Bsoft Limited</NavbarBrand>
                <Navbar.Toggle aria-controls="basic-navbar-nav" />
                <Navbar.Collapse id="basic-navbar-nav">
                    <Nav variant="pills" className="me-auto">
                        <Nav.Link className={active === "home" ? "nav-link active": "nav-link"} onClick={scrollToHome}>Home</Nav.Link>
                        <Nav.Link className={active === "about" ? "nav-link active": "nav-link"} onClick={scrollToAbout}>About</Nav.Link>              
                        <Nav.Link className={active === "services" ? "nav-link active": "nav-link"} onClick={scrollToServices}>Services</Nav.Link>
                        <Nav.Link className={active === "users" ? "nav-link active": "nav-link"} onClick={scrollToUsers}>Users</Nav.Link>
                        <Nav.Link className={active === "downloads" ? "nav-link active": "nav-link"} onClick={scrollToDownloads}>Downloads</Nav.Link>
                        <Nav.Link className={active === "projects" ? "nav-link active": "nav-link"} onClick={scrollToProjects}>Projects</Nav.Link>
                        <Nav.Link className={active === "contacts" ? "nav-link active": "nav-link"} onClick={scrollToCOntacts}>Contacts</Nav.Link>
                    </Nav>
                    <Nav variant="pills" className="navbar-end align-right">
                        { initQuery.data?.data && (<Nav.Item>
                            <img className="rounded-circle me-1 border bg-white" src={profile} width="45" height="45"/>
                            <span className="text-white"> Hi {initQuery.data?.data.name}</span>
                        </Nav.Item>) }

                        { initQuery.data?.data && (<NavDropdown title={(<FaBell size={24} className="text-light"/>)} id="nav-dropdown-notifications">
                           
                        </NavDropdown>) }

                        { initQuery.data?.data && (<NavDropdown title={(<FaCogs size={24} className="text-light"/>)} id="nav-dropdown-settings">
                            <NavDropdown.Item eventKey="4.1" style={{fontSize: "12px"}} as={Link} to={"/dashboard"}>Dashboard</NavDropdown.Item>
                            <NavDropdown.Item eventKey="4.2" style={{fontSize: "12px"}} as={Link} to={"/dashboard/settings"}>Settings</NavDropdown.Item>  
                            <NavDropdown.Divider />  
                            <NavDropdown.Item eventKey="4.4" style={{fontSize: "12px"}} onClick={signout}>Signout</NavDropdown.Item>
                        </NavDropdown>) }
                        
                        { !initQuery.data?.data && (<Nav.Item>
                            <Nav.Link className="text-light" as={Link} to={"/signin"}>Signin</Nav.Link>
                        </Nav.Item>) }
                    </Nav>
                </Navbar.Collapse>
            </Container>
        </Navbar>
    );
}

export default Header;