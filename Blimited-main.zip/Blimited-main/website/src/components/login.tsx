import { Button, Form } from "react-bootstrap";
import { LoginRequest } from "../utils/requests";
import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useMutation } from "react-query";
import { axiosInstance } from "../utils/authcontext";
import { CircleLoading } from "bsoft-react-ui";

const Login = () =>{
    const [navigate, params] = [ useNavigate(), useParams() ];


    let prev = params.prev && params.prev.replaceAll("_", "/");
    const [loginDetails, setLoginDetails] = useState<LoginRequest>({email: "", password: ""});
    
    const loginChange = (event: React.ChangeEvent<HTMLInputElement>) =>{
        let input = event.currentTarget;
        switch(input.id){
            case "loginEmail":
                setLoginDetails({...loginDetails, email: input.value});
                break;
            case "loginPassword":
                setLoginDetails({...loginDetails, password: input.value});
                break;
        }
    }

    const loginMutation = useMutation({
        mutationKey: ['credentials'],
        mutationFn: (loginDetails: LoginRequest) => axiosInstance.post('/users/login', loginDetails),
        onSuccess: () => {
            navigate(prev || "/");  
        },
        onError(error) {
            alert(JSON.stringify(error));
        },
    });

    const handleSubmit = (event: React.UIEvent<HTMLFormElement>) => {
        event.preventDefault();
        loginMutation.mutate(loginDetails);
    };

    return (
        <Form className="slidin" onSubmit={handleSubmit}>
            <Form.Group controlId="loginEmail">
                <Form.Label className="form-label">Email</Form.Label>
                <Form.Control className="form-input" onChange={loginChange} required type="email" placeholder='Enter your Email'/>
            </Form.Group>
            <Form.Group controlId="loginPassword">
                <Form.Label className="form-label">Password</Form.Label>
                <Form.Control className="form-input" onChange={loginChange} required type="password" placeholder="Enter your Password" />
            </Form.Group>
            <Button  variant="primary" className='options-btn' type="submit">
                { loginMutation.isLoading && ( <CircleLoading message={"Signing in ..."}/> ) }
                { !loginMutation.isLoading && "Login" }
            </Button>
        </Form>);
}

export default Login;