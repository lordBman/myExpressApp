import AdminPage from "./admin";

export { AdminPage };