import { OptionBar } from "bsoft-react-ui";
import { FaUsers } from "react-icons/fa";

const Workers = () =>{
    return (
        <OptionBar title="Workers"><FaUsers size={24}/></OptionBar>
    );
}

export default Workers;