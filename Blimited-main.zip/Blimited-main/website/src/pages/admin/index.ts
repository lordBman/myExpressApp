import Clients from "./clients";
import Events from "./events";
import Home from "./home";
import Info from "./info";
import Notifications from "./notifications";
import Projects from "./projects";
import Settings from "./settings";
import Sugestions from "./sugestions";
import Workers from "./workers";

export default { Clients, Events, Home, Info, Notifications, Projects, Settings, Workers, Sugestions }