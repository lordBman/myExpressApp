import { OptionBar } from "bsoft-react-ui";
import { FaCodepen } from "react-icons/fa";

const Sugestions = () =>{
    return (
        <OptionBar title="Sugestions"><FaCodepen size={24}/></OptionBar>
    );
}

export default Sugestions;