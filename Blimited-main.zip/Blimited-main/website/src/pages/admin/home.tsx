import { OptionBar } from "bsoft-react-ui";
import { FaHome } from "react-icons/fa";

const Home = () =>{
    return (
        <OptionBar title="Home"><FaHome size={24}/></OptionBar>
    );
}

export default Home;