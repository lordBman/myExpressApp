import { OptionBar } from "bsoft-react-ui";
import { FaHandsHelping } from "react-icons/fa";

const Clients = () =>{
    return (
        <OptionBar title="Clients"><FaHandsHelping size={24}/></OptionBar>
    );
}

export default Clients;