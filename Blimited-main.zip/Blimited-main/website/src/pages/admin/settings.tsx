import { OptionBar } from "bsoft-react-ui";
import { FaCogs } from "react-icons/fa";

const Settings = () =>{
    return (
        <OptionBar title="Settings"><FaCogs size={24}/></OptionBar>
    );
}

export default Settings;