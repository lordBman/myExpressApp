import { OptionBar } from "bsoft-react-ui";
import { FaInfoCircle } from "react-icons/fa";

const Info = () =>{
    return (
        <OptionBar title="Help"><FaInfoCircle size={24}/></OptionBar>
    );
}

export default Info;