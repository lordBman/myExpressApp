import { OptionBar } from "bsoft-react-ui";
import { FaRegCalendarAlt } from "react-icons/fa";

const Events = () =>{
    return (
        <OptionBar title="Event Management"><FaRegCalendarAlt size={24}/></OptionBar>
    );
}

export default Events;