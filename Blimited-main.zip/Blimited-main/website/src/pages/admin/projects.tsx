import { OptionBar } from "bsoft-react-ui";
import { FaProjectDiagram } from "react-icons/fa";

const Projects = () =>{
    return (
        <OptionBar title="Projects"><FaProjectDiagram size={24}/></OptionBar>
    );
}

export default Projects;