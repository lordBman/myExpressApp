import { OptionBar } from "bsoft-react-ui";
import { FaRegBell } from "react-icons/fa";

const Notifications = () =>{
    return (
        <OptionBar title="Notifications"><FaRegBell size={24}/></OptionBar>
    );
}

export default Notifications;