import { HashRouter, Route, Routes} from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.css';
import "bsoft-react-ui/dist/styles/app.css";
import "./assets/styles/app.scss";
import { ClientSignUp, Dashboard, Downloads, Home, Signin, WorkerSignUp } from "./screens";
import { PrivateRoute, Role } from "./routes";

const App = () =>{
    switch(window.location.host.split(".")[0]){
        case "downloads":
            return (
                <HashRouter>
                    <Routes>
                        <Route index element={<Downloads />} />
                        <Route path="/:id" element={<Downloads />} />
                        <Route path="/:id/:option" element={<Downloads />} />
                    </Routes>
                </HashRouter>
            );
    }

    return (
        <HashRouter>
            <Routes>
                <Route index element={<Home />}/>
                <Route path="/signin" element={<Signin />}/>
                <Route path="/signin/:prev" element={<Signin />} />

                <Route path="/worker/signup" element={<PrivateRoute roles={[Role.None]} element={<WorkerSignUp />}/> } />
                <Route path="/client/signup" element={<PrivateRoute roles={[Role.None]} element={<ClientSignUp />}/> } />

                <Route path="/dashboard" element={<PrivateRoute roles={[Role.Admin, Role.Client, Role.Worker]} element={<Dashboard />}/> }/>
                <Route path="/dashboard/:option" element={<PrivateRoute roles={[Role.Admin, Role.Client, Role.Worker]} element={<Dashboard />}/> }/>
                <Route path="/dashboard/:option/:subOption" element={<PrivateRoute roles={[Role.Admin, Role.Client, Role.Worker]} element={<Dashboard />}/> }/>
                <Route path="/dashboard/:option/:subOption/:section" element={<PrivateRoute roles={[Role.Admin, Role.Client, Role.Worker]} element={<Dashboard />}/> }/>
            </Routes>
        </HashRouter>
    );
}

export default App;