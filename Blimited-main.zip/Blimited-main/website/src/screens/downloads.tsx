import { useParams } from "react-router-dom";

const Downloads = () =>{
    const params = useParams();
    return (
        <div>
            Downloads { params.id && `-${params.id}` } { params.option && `:${params.option}` }
        </div>
    );
}

export default Downloads;