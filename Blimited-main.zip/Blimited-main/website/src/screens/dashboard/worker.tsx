const Worker = () =>{
    return  (<label>Worker</label>);
}

export default Worker;