import "../../assets/styles/dashboard.scss";

import { FaCodepen, FaCogs, FaHandsHelping, FaHome, FaInfoCircle, FaProjectDiagram, FaRegBell, FaRegCalendarAlt, FaUsers } from "react-icons/fa";
import { Image, Nav, NavDropdown } from 'react-bootstrap';
import { Link, useParams } from 'react-router-dom';
import profile from "../../assets/images/profile.png";
import { AdminPage } from "../../pages";
import { useQueryClient } from "react-query";
import { UserState } from "../../items/user";
import { Dashboard, SideBar } from "bsoft-react-ui";

const Admin = () => {
    const queryClient = useQueryClient();
    let params = useParams();
    let userData = queryClient.getQueryData<any>(["user"]).data as UserState;

    return (
        <Dashboard>
            <Dashboard.Toolbar className="bg-primary shadow px-2" style={{ justifyContent:"end" }}>
                <Nav variant="pills" className="navbar-end align-right">
                    <Nav.Item>
                        <Image roundedCircle className="me-1 border bg-white" src={profile} width="45" height="45"/>
                        <span className="text-white"> Hi { userData.user?.name }</span>
                    </Nav.Item>
                    <NavDropdown title={(<FaCogs size={24} className="text-light"/>)}>
                        <NavDropdown.Item eventKey="4.1" style={{fontSize: "12px"}} as={Link} to={"/dashboard"}>Profile</NavDropdown.Item>
                        <NavDropdown.Item eventKey="4.2" style={{fontSize: "12px"}} as={Link} to={"/dashboard/settings"}>Settings</NavDropdown.Item>  
                        <NavDropdown.Divider />  
                        <NavDropdown.Item eventKey="4.4" style={{fontSize: "12px"}}>Signout</NavDropdown.Item>
                    </NavDropdown>
                </Nav>
            </Dashboard.Toolbar>
            <SideBar className="bg-white">
                <SideBar.Header title="Bsoft Limited" className="bg-primary-dark text-white p-3" style={{ fontSize:"14px", fontWeight:"600"}}/>
                <SideBar.Content className="text-grey-dark" style={{gap: 0, fontSize:"14px", borderRight: "1px solid grey"}}>
                    <SideBar.Item title="Home" to='/dashboard' className={ !params.option ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaHome size={22} /></SideBar.Item>
                    <SideBar.Item title="Events" to='/dashboard/events' className={ params.option ==="events" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaRegCalendarAlt size={22} /></SideBar.Item>
                    <SideBar.Item title="Notifications" to='/dashboard/notifications' className={ params.option ==="notifications" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaRegBell size={22} /></SideBar.Item>
                    <SideBar.Item title="Projects" to='/dashboard/projects' className={ params.option ==="projects" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaProjectDiagram size={22} /></SideBar.Item>
                    <SideBar.Item title="Workers" to='/dashboard/workers' className={ params.option ==="workers" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaUsers size={22} /></SideBar.Item>
                    <SideBar.Item title="Clients" to='/dashboard/clients' className={ params.option ==="clients" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaHandsHelping size={22} /></SideBar.Item>
                </SideBar.Content>
                <SideBar.Footer className="text-grey-dark" style={{ gap:0, fontSize:"14px", borderRight: "1px solid grey", borderBottom: "1px solid grey"}}>
                    <SideBar.Item title="Help" to='/dashboard/sugestions' className={ params.option ==="sugestions" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaCodepen size={22} /></SideBar.Item>
                    <SideBar.Item title="Settings" to='/dashboard/settings' className={ params.option ==="settings" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaCogs size={22} /></SideBar.Item>
                    <SideBar.Item title="Help" to='/dashboard/help' className={ params.option ==="help" ? 'p-3 w-100 sidebar-item-active' : "p-3 w-100"}><FaInfoCircle size={22} /></SideBar.Item>
                </SideBar.Footer>
            </SideBar>
            <Dashboard.Main className='container-fluid main' style={{position:"relative"}}>
                { (!params.option || params.option === "/")  && (<AdminPage.Home />) }
                { params.option && params.option === "clients"  && (<AdminPage.Clients />) }
                { params.option && params.option === "help"  && (<AdminPage.Info />) }
                { params.option && params.option === "events"  && (<AdminPage.Events />) }
                { params.option && params.option === "notifications"  && (<AdminPage.Notifications />) }
                { params.option && params.option === "settings"  && (<AdminPage.Settings />) }
                { params.option && params.option === "projects"  && (<AdminPage.Projects />) }
                { params.option && params.option === "workers"  && (<AdminPage.Workers />) }
                { params.option && params.option === "sugestions"  && (<AdminPage.Sugestions />) }
            </Dashboard.Main>
        </Dashboard>
    );
};

export default Admin;