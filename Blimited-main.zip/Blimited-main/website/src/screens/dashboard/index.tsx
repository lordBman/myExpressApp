import { useQueryClient } from "react-query";
import Admin from "./admin";
import Client from "./client";
import Worker from "./worker";
import { UserState } from "../../items/user";

const Dashboard = () =>{
    const queryClient = useQueryClient();
    let userData = queryClient.getQueryData<any>(["user"]).data as UserState;
    
    switch(userData.user?.type){
        case "admin":
            return (<Admin />);
        case "client":
            return (<Client />);
        case "worker":
            return  (<Worker />);
    }

    return (<div>Error Encoutered</div>);
}

export default Dashboard;