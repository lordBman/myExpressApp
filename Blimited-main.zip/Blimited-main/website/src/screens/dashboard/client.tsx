const Client = () =>{
    return  (<label>Client</label>);
}

export default Client;