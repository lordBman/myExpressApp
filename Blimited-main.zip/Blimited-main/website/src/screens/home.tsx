import { Button, Card, Col, Container, Image, Row } from "react-bootstrap";
import Header from "../components/header";
import "../assets/styles/home.scss";
import programming from "../assets/images/programming.svg";
import quiting from "../assets/images/quitting.svg";
import app from "../assets/images/app.png";
import web from "../assets/images/web.png";
import design from "../assets/images/design.png";
import game from "../assets/images/game.png";
import smartphones from "../assets/images/smartphones.png";
import database from "../assets/images/database.png";
import tools from "../assets/images/design_tools.svg";
import mobile from "../assets/images/mobile.svg";
import { Link } from "react-router-dom";
import Footer from "../components/footer";

const Home = () =>{
    return (
        <div>
            <Header />
            <section className="image image-responsive jumbotron-bg" style={{ paddingTop: "100px", paddingBottom: "40px" }} id="home">
                <Container fluid={true} className="px-md-3 px-lg-5">
                    <div className="jumbotron text-center" style={{color: "white"}}>
                        <h1 className="title">Bsoft Limited</h1>
                        <p>Bringing mere ideas to Light</p>
                    </div>
                </Container>
            </section>

            <section id="about" style={{ paddingTop:"80px" }}>
                <Container fluid={true} className="px-md-3 px-lg-5">
					<Row>
						<Col md={6}>
							<h2 className="text-primary" style={{fontWeight:"600"}}>Bsoft Limited</h2>
							<p>
								This is an online based software company solely founded by CEO, <strong>Okelekele Nobel Bobby</strong>, a passionate software and game developer vast in the knowlege 
								of software development, 3D programming, Web design and Development.<br/>
								We offer a wide rage of services ranging from software development to graphics design, to gmae developement and we support 
								all platforms. our staff of developers are passionate about thier given task and ensures they are up to speed with modern
								design and development practices, all this just to ensure we delivery the best services available not just to users of our
								products ie websites, software, games, designs, etc. but also to you the clients.
							</p>
						</Col>
						<Col md={6} className="bg-white">
							<div style={{width:"80%", height:"80%", margin:"auto"}} className="logo">
								<Image fluid={true} src={programming} />
							</div>
						</Col>
					</Row>
				</Container>
			</section>

            <section id="services" style={{ paddingTop:"80px" }}>
                <Container fluid={true} className="px-md-3 px-lg-5">
					<h3 className="text-blue" style={{fontWeight:"700", fontSize:"2em"}}>Services</h3>
					<Row className="text-center">
						<Col md={6}>
							<p style={{fontSize:"15px", fontWeight:"400", textAlign:"left"}}>
								As stated previously, we offer wide range of services, the six most basic services are listed below. note we are not limited to only the services listed below, any computer software
								related services is rendered by us, I mean this is a software company right.
							</p>
							<Image fluid className="mt-2" src={quiting} />
						</Col>
						<Col md={6}>
							<Row>
								<Col md={6} className="pt-2">
									<Card className="text-center card shadow rounded-3 px-2 pt-3" style={{height:"250px"}}>
										<div className="logo-small"><Image fluid={true} src={app} /></div>
										<h6>App Development</h6>
										<p style={{fontSize:"14px"}}>
											We build software for all platforms weather it's Android, IOS, MAC, Windows, and even embedded systems. we always 
											keep both client and user satisfaction in mind when building softwares so as to not only satisfy our client but also the
											end user.
										</p>
									</Card>
								</Col>
								<Col md={6} className="pt-2">
									<Card className="text-center shadow rounded-3 px-2 pt-3" style={{height:"250px"}}>
										<div className="logo-small"><Image fluid={true} src={web} /></div>
										<h6>Web Design</h6>
										<p style={{fontSize:"14px"}}>
											We always strive to build beautiful and Dynamic websites using the latest design trends and practices, to deliver a very responsive and
											clean up to date user experience wether on Desktop or mobile devices.
										</p>
									</Card>
								</Col>
								<Col md={6} className="pt-2">
									<Card className="text-center shadow rounded-3 px-2 pt-3" style={{height:"200px"}}>
                                        <div className="logo-small"><Image fluid={true} src={game} /></div>
										<h6>Game Development</h6>
										<p style={{fontSize:"14px"}}>
											We create game both 2D and 3D for all platforms across different genre 
											such as RGPs, 2D and 3D platforms, 
											side Scrolling Adventures Games. 
										</p>
									</Card>
								</Col>
								<Col md={6} className="pt-2">
									<Card className="text-center shadow rounded-3 px-2 pt-3" style={{height:"200px"}}>
                                        <div className="logo-small"><Image fluid={true} src={design} /></div>
										<h6>Graphics Design</h6>
										<p style={{fontSize:"14px"}}>
											We offer graphics design services ranging from creatng banners and posters to 2D and 3D animations.
										</p>
									</Card>
								</Col>
								<Col md={6} className="text-center pt-2">
									<Card className="shadow rounded-3 px-2 pt-3" style={{height:"210px"}}>
                                        <div className="logo-small"><Image fluid={true} src={smartphones} /></div>
										<h6>Mobile App</h6>
										<p style={{fontSize:"14px"}}>You can download our complimentary mobile app below. with it you have almost all the convinence of the website but on in you pocket and so much mmore.</p>
									</Card>
								</Col>
								<Col md={6} className="pt-2">
									<Card className="text-center card shadow rounded-3 px-2 pt-3" style={{height:"210px"}}>
                                        <div className="logo-small"><Image fluid={true} src={database} /></div>
										<h6>Data Mining and Analysis</h6>
										<p style={{fontSize:"14px"}}>We also scout and gather data and informations and make analysis and tactics based on the informtion gathered.</p>
									</Card>
								</Col>
							</Row>
						</Col>
					</Row>
				</Container>
			</section>

			<section id="users" style={{ paddingTop:"80px" }}>
				<div className="px-3 pb-3 pt-5" style={{backgroundColor:"#f8f8f8"}}>
					<Container fluid={true} className="px-md-3 px-lg-5">
						<h2 className="text-blue" style={{fontWeight:"600"}}>Users of the Site</h2>
						<Row>
							<Col md={6}>
								<p style={{fontSize:"15px"}}>
									There are three different types of users of this site, we have the visitor, the client, and the workers. when you register with
									us, are regarded as a visitor. and as a visitor, you have limited priviledges, but atleast you can drop comment and contact us, and 
									you can use your account with our other services.
								</p>
								<Image fluid className="p-3" src={tools}/>
							</Col>
							<Col md={6}>
								<div>
									<h3 className="text-blue" style={{fontWeight:"600"}}>Becoming a client</h3>
									<p style={{fontSize:"15px"}}>
										As a client, you have the priviledge to drop Job request and negociate like building of websites, softwars for desktop and mobile devices and many more,
										communicate with our staffs, monitor your ongoing project that is the once you
										requested and was accepted, request meetings with us, and live chat with us. 
									</p>
									<Link className="btn btn-outline-primary" to={"/signin"} style={{fontSize:"12px"}}>Signup</Link>
								</div>
								<div className="pt-5">
									<h3 className="text-blue" style={{fontWeight:"600"}}>Start working with us</h3>
									<p style={{fontSize:"15px"}}>
										You can register as aworker on our platform, you get the oppurtunity to join our staff of professionals, work based on your specialty,
										and pick up other skills by learn in
										the process of working on projects with others.
									</p>							
									<a className="btn btn-outline-primary" href="signup.php?mode=3" style={{fontSize:"12px"}}>Apply</a>
								</div>
							</Col>
						</Row>
					</Container>
				</div>
			</section>

			<section id="downloads" style={{ paddingTop:"80px" }}>
				<Container fluid={true} className="px-md-3 px-lg-5">
					<h3 className="text-blue" style={{fontWeight:"600"}}>Downloads</h3>
					<Row>
						<Col sm={12}>
							<p style={{fontSize:"14px", fontWeight:"400"}}>
							You can download our Software Apllications and Games, you could also gve us feedback on our software, 
							which will be realy appreciated. You could also check out, clone and contribute to our open source projects
							and your contributions won't go unnoticed.
							</p>
						</Col>
						<Col sm={12} style={{textAlign:"right"}}>
							<a className="btn btn-outline-primary mt-3 shadow" style={{fontSize:"13px", fontWeight:"500"}} href="downloads.php">More Downloads</a>
						</Col>
						<Col md={4} className="mt-3">
							<div className="logo"><Image fluid src={mobile} /></div>
						</Col>
						<Col md={8} className="mt-3">
							<h3  className="text-blue" style={{fontWeight:"600"}}>Download Bsoft Mobile</h3>
							<h6>Download the mobile App</h6>
							<div style={{fontSize:"15px"}}>You can download our complimentary mobile app, with this app you have faster access to our projects, downloads and can better keep track of our 
							activities and show support. It has a slick and easy to use interface that change depending on the type of the kind of user you are.
								<Row>
									<Col sm={4}>
										<h6>For the Visitors:</h6>
										<ul className="list" style={{fontSize:"15px"}}>
											<li>Download our Apps</li>
											<li>Give feedbacks</li>
										</ul>
									</Col>
									<Col sm={4}>
										<h6>For the Clients:</h6>
										<ul className="list" style={{fontSize:"15px"}}>
											<li>Monitior your Porjects</li>
											<li>Chat with our staffs</li>
											<li>Job Request</li>
											<li>Downoad our Apps</li>
										</ul>
									</Col>
									<Col sm={4}>
										<h6>For the Workers:</h6>
										<ul className="list" style={{fontSize:"15px"}}>
											<li>Monitor your Projets</li>
											<li>Full access to our Repo</li>
											<li>Project Updating</li>
										</ul>
									</Col>
								</Row>
								<Button variant="outline-primary" style={{fontSize:"12px", textAlign:"center", margin:"10px"}}>Download App</Button>
							</div>
						</Col>
					</Row>
				</Container>
			</section>
			<Footer />
        </div>
    );
}

export default Home;