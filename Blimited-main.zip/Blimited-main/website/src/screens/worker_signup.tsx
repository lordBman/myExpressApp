const WorkerSignUp = () =>{
    return (<div>Worker Sign Up</div>)
}

export default WorkerSignUp;