const ClientSignUp = () =>{
    return (<div>Client Sign Up</div>)
}

export default ClientSignUp;