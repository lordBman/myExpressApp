import { Button, Col, Container, Row } from "react-bootstrap";
import { useState } from "react";
import "../assets/styles/signin.scss";
import { Link } from "react-router-dom";
import { FaHome } from "react-icons/fa";
import { Login, SignUp } from "../components";


const Signin = () =>{
    const [login,  setLogin] = useState(true);

    const openLoginForm = () => setLogin(true);
    const openSignupForm = () => setLogin(false);

    return (
        <div>
            <Container fluid>
                <Row className='content'>
                    <Col lg={6} className="content-container">
                        <h2 className='content-header'>Bsoft Limited</h2>
                        <p className='content-item'>
                            Baptême de tabarnane de cimonaque d'étole de patente à gosse de maudit de cossin de colon de cibouleau de saint-ciboire.
                            Cul de bout d'ciarge de Jésus Marie Joseph de câlique de colon de câline de sacréfice de mosus de batèche d'étole.
                            Saintes fesses d'ostie de sapristi de mosus de boswell de baptême de torrieux de caltor de purée de crucifix.
                            Verrat de viande à chien de calvince de gériboire de cibouleau de calvinouche de bâtard de christie de crucifix de doux Jésus.
                            Saintes fesses de Jésus Marie Joseph de sacristi de ciboire de charogne d'enfant d'chienne de bâtard de cul de mosus de saint-ciboire.
                        </p>
                        <div style={{ float: "right" }}>
                            <Link to={"/"} className="btn btn-outline-light" style={{borderRadius: "20px"}}><FaHome size={24} /> to Homepage</Link> 
                        </div>
                    </Col>
                    <Col lg={6} className="text-center">
                        <div className='forms shadow'>
                            <Row style={{marginBottom: "30px"}}>
                                <Col sm={6} className='pe-1'>
                                    <Button variant={ login ? "primary" : "outline-primary" } className="options-btn"  onClick={openLoginForm}>Login</Button>
                                </Col>
                                <Col sm={6} className='ps-1'>
                                    <Button variant={ !login ? "primary" : "outline-primary" } className="options-btn" onClick={openSignupForm}>Sign Up</Button>
                                </Col>
                            </Row>

                            {login && (<Login />) }
                            { !login  &&  (<SignUp />)}
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}

export default Signin;