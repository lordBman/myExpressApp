import { ErrorHandler } from "../error";
import { AcademiaTables, BlimitedTables, GistTables } from "../tables";

export default abstract class BaseDatabase<T> {
    errorHandler: ErrorHandler;
    protected connection?: T;

    protected constructor(error: ErrorHandler){
        console.log(process.env.DB_USER);
        this.errorHandler = error;

        this.connect().then((connection: T)=>{
            this.connection = connection;
            new AcademiaTables(this as any).check().catch((error)=>{
                throw new Error(error);
            })
            new BlimitedTables(this as any).check().catch((error)=>{
                throw new Error(error);
            });
            new GistTables(this as any).check().catch((error)=>{
                throw new Error(error);
            });
            console.log("done checking");

        }).catch((error)=>{
            this.errorHandler.add(500, JSON.stringify(error.stack), "unable to connect to database");
        });
    }

    abstract connect(): Promise<T>;
    abstract createTable(query: string): Promise<boolean>;
    abstract insert(query: string, params?: any[], errorMessage?: string) : Promise<number>;
    abstract get(query: string, params?: any[], errorMessage?: string) : Promise<any[]>;
    abstract update(query: string, params?: any[], errorMessage?: string) : Promise<boolean>;
}