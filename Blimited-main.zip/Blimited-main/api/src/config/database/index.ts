import { ErrorHandler } from "../error";
import Database from "./base";
import MySQLDatabase from "./mysql";
import SQLiteDatabase from "./sqlite";

class DBManager{
    private static db: Database<any>;
    private constructor(){}

    static instance = () =>{
        if(!DBManager.db){
            switch(process.env.DB){
                case "mysql":
                    DBManager.db = new MySQLDatabase(new ErrorHandler());
                    break;
                default:
                    DBManager.db = new SQLiteDatabase(new ErrorHandler());
            }
        }
        return DBManager.db;
    }
}

export { DBManager };