import mysql from "mysql2";
import BaseDatabase from "./base";
import { ErrorHandler } from "../error";


export default class MySQLDatabase extends BaseDatabase<mysql.Connection>{

    constructor(error: ErrorHandler){
        super(error);
    }

    connect(): Promise<mysql.Connection> {
        return new Promise<mysql.Connection>((resolve, reject)=>{
            let init = mysql.createConnection({ host: process.env.DB_HOST, database: process.env.DB_NAME, user: process.env.DB_USER, password: process.env.DB_PWD });
            init.connect((error)=>{
                if(error){
                    reject(error);
                }
                resolve(init);
            })
        });
    }
    
    public createTable(query: string): Promise<boolean>{
        return new Promise<boolean>((resolve, reject) =>{
            this.connection?.query( query, (error, result) => {
                if (error) {
                    this.errorHandler.add(500, JSON.stringify(error.stack), "server encountered error while creating table");
                    reject(error);
                }else{
                    resolve(true);
                }
            });
        });
    }
    
    insert(query: string, params?: any[], errorMessage?: string) : Promise<number>{
        return new Promise<number>((resolve, reject) =>{
            this.connection?.query( query, params, (error, result) => {
                if (error) {console.log(`server error: ${query}-  ${error.stack}`);
                  this.errorHandler.add(500, JSON.stringify(error.stack), errorMessage ?? "server error");
                  reject(error.stack);
                };
                resolve((result as mysql.ResultSetHeader)?.insertId);
            });
        });
    }

    get(query: string, params?: any[], errorMessage?: string) : Promise<any[]>{
        return new Promise<any>((resolve, reject) =>{
            this.connection?.query( query, params, (error, result) => {
                if (error) {console.log(`server error: ${query}-  ${error.stack}`);
                  this.errorHandler.add(500, JSON.stringify(error.stack), errorMessage ?? "server error");
                  reject(error.stack);
                };
                resolve(result);
            });
        });
    }

    update(query: string, params?: any[], errorMessage?: string) : Promise<boolean>{
        return new Promise<boolean>((resolve, reject) =>{
            this.connection?.query( query, params, (error) => {
                if (error) {console.log(`server error: ${query}-  ${error.stack}`);
                  this.errorHandler.add(500, JSON.stringify(error.stack), errorMessage ?? "server error");
                  reject(error.stack);
                };
                resolve(true);
            });
        });
    }
}