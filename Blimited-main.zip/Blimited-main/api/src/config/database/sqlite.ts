import { Database, RunResult, sqlite3 } from "sqlite3";
import { ErrorHandler } from "../error";
import BaseDatabase from "./base";

export default class SQLiteDatabase extends BaseDatabase<Database>{
    constructor(error: ErrorHandler){
        super(error);
    }

    private attach (db: Database, dbName: string, dbPath: string): Promise<boolean>{
        return new Promise<boolean>((resolve, reject)=>{
            db.run(`ATTACH DATABASE '${dbPath}' AS ${dbName};`, (attachError) => {
                if (attachError) {
                    console.error('Error attaching database:', attachError.message);
                    reject(attachError.stack);
                } else {
                    console.log(`Database ${dbName} attached successfully.`);
                    resolve(true);
                }
            });
        });
    }

    private alias(db: Database): Promise<boolean>{
        return new Promise<any>((resolve, reject)=>{
            db.run(`ATTACH DATABASE '' AS ${process.env.DB_NAME};`, (attachError) => {
                if (attachError) {
                  console.error('Error attaching database:', attachError.message);
                  reject(attachError.stack);
                } else {
                  console.log('Database attached successfully.');
                  resolve(true);
                }
            })
        });
    }

    connect(): Promise<Database> {
        return new Promise<any>((resolve, reject)=>{
            let init = new Database("./databases/blimited.sql", async (error)=>{
                if(error){
                    reject(error);
                }
                //await this.alias(init);
                await this.attach(init, process.env.CHAT_DB_NAME!, "./databases/chat.sql").catch(error => reject(error));
                await this.attach(init, process.env.ACADAMIA_DB_NAME!, "./databases/academia.sql").catch(error => reject(error));
                await this.attach(init, process.env.GIST_DB_NAME!, "./databases/gist.sql").catch(error => reject(error));
                resolve(init);
            });
        });
    }

    createTable(query: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject)=>{
            this.connection?.run(query, (error)=>{
                if (error) {
                    this.errorHandler.add(500, JSON.stringify(error.stack), "server encountered error while creating table");
                    reject(error);
                }else{
                    resolve(true);
                }
            });
        });
    }

    insert(query: string, params?: any[] | undefined, errorMessage?: string | undefined): Promise<number> {
        return new Promise<number>((resolve, reject)=>{
            let errorHandler = this.errorHandler;
            this.connection?.run( query, params, function(error) {
                if (error) {console.log(`server error: ${query}-  ${error.stack}`);
                  errorHandler.add(500, JSON.stringify(error.stack), errorMessage ?? "server error");
                  reject(error.stack);
                };
                resolve(this.lastID);
            });
        });
    }

    get(query: string, params?: any[] | undefined, errorMessage?: string): Promise<any[]> {
        return new Promise<any>((resolve, reject)=>{
            this.connection?.run(query,)
            this.connection?.all( query, params, (error, row) => {
                if (error) {console.log(`server error: ${query}-  ${error.stack}`);
                  this.errorHandler.add(500, JSON.stringify(error.stack), errorMessage ?? "server error");
                  reject(error.stack);
                };
                resolve(row);
            });
        });
    }

    update(query: string, params?: any[], errorMessage?: string): Promise<boolean> {
        return new Promise<boolean>((resolve, reject)=>{
            this.connection?.run(query,)
            this.connection?.run( query, params, (error) => {
                if (error) {console.log(`server error: ${query}-  ${error.stack}`);
                  this.errorHandler.add(500, JSON.stringify(error.stack), errorMessage ?? "server error");
                  reject(error.stack);
                };
                resolve(true);
            });
        });
    }
}