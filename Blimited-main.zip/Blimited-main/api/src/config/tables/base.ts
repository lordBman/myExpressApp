import Database from "../database/base";

export abstract class Table{
    private db: Database<any>;

    constructor(db: Database<any>){ this.db = db; }

    async check(){
        const tables = this.setTables();
        for(let i = 0; i < tables.length; i++){
            try {
                await this.db.createTable(tables[i]);
            }catch (error) {
                console.error(error);
                this.db.errorHandler.add(500, error as string, "server error");
            }
        }
    }

    abstract setTables(): string[];
}