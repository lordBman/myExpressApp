import { Table } from "./base";

const mysql_users = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Users (
    id INT UNSIGNED PRIMARY KEY,
    status TEXT NOT NULL, joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);`;

const sqlite_users = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Users (
    id INTEGER PRIMARY KEY, status TEXT NOT NULL,
    joined DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP);`;

const postgres_users = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Users (
    id SERIAL PRIMARY KEY, status TEXT NOT NULL,
    joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);`;



const mysql_comments = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Comments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ownerID INT UNSIGNED NOT NULL, senderID INT UNSIGNED NOT NULL, message TEXT NOT NULL, likes INT NOT NULL DEFAULT '0',
    dislikes INT NOT NULL DEFAULT '0', FOREIGN KEY (senderID) REFERENCES Users(id ));`;

const sqlite_comments = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT, time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    ownerID INTEGER NOT NULL, senderID INTEGER NOT NULL, message TEXT NOT NULL, likes INTEGER NOT NULL DEFAULT 0,
    dislikes INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (senderID) REFERENCES Users(id));`;

const postgres_comments = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Comments (
    id SERIAL PRIMARY KEY, time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, ownerID INTEGER NOT NULL,
    senderID INTEGER NOT NULL, message TEXT NOT NULL, likes INTEGER NOT NULL DEFAULT 0, dislikes INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (senderID) REFERENCES Users(id));`;


const mysql_user_posts = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.UserPosts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, senderID INT UNSIGNED NOT NULL, message TEXT NOT NULL, 
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, likes INT NOT NULL DEFAULT '0',
    dislikes INT NOT NULL DEFAULT '0', FOREIGN KEY (senderID) REFERENCES Users(id));`;

const sqlite_user_posts = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.UserPosts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, senderID INTEGER NOT NULL, message TEXT NOT NULL,
    time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, likes INTEGER NOT NULL DEFAULT 0,
    dislikes INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (senderID) REFERENCES Users(id));`;

const postgres_user_posts = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.UserPosts (
    id SERIAL PRIMARY KEY, senderID INTEGER NOT NULL, message TEXT NOT NULL,
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, likes INTEGER NOT NULL DEFAULT 0,
    dislikes INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (senderID) REFERENCES Users(id));`;



const mysql_group_posts = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.GroupPosts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, senderID INT UNSIGNED NOT NULL, message TEXT NOT NULL,
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, groupID INT UNSIGNED NOT NULL, likes INT NOT NULL DEFAULT '0',
    dislikes INT NOT NULL DEFAULT '0', FOREIGN KEY (senderID) REFERENCES Users(id));`;

const sqlite_group_posts = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.GroupPosts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, senderID INTEGER NOT NULL, message TEXT NOT NULL,
    time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, groupID INTEGER NOT NULL, likes INTEGER NOT NULL DEFAULT 0,
    dislikes INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (senderID) REFERENCES Users(id));`;

const postgres_group_posts = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.GroupPosts (
    id SERIAL PRIMARY KEY, senderID INTEGER NOT NULL, message TEXT NOT NULL,
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, groupID INTEGER NOT NULL, likes INTEGER NOT NULL DEFAULT 0,
    dislikes INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (senderID) REFERENCES Users(id));`;

export default class GistTables extends Table{
    setTables(): string[] {
        switch(process.env.DB){
            case "mysql":
                return [mysql_users, mysql_comments, mysql_user_posts, mysql_group_posts];
            case "postgres":
                return [postgres_users, postgres_comments, postgres_user_posts, postgres_group_posts];
            default:
                return [sqlite_users, sqlite_comments, sqlite_user_posts, sqlite_group_posts];
        }
    }
}