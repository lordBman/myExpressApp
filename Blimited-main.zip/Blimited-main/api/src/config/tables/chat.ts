import { Table } from "./base";


const mysql_users = `CREATE TABLE IF NOT EXISTS ${process.env.GIST_DB_NAME}.Users (
    id INT UNSIGNED PRIMARY KEY, last TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);`;

const sqlite_users = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Users (
    id INTEGER PRIMARY KEY, status TEXT NOT NULL,
    last DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP);`;

const postgres_users = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Users (
    id SERIAL PRIMARY KEY, status TEXT NOT NULL,
    last TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP);`;



const mysql_chat = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Chats (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, userID INT UNSIGNED NOT NULL,
    message TEXT NOT NULL, time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    receiverID INT UNSIGNED NOT NULL, type ENUM("private", "group") DEFAULT "private", refrenceID INT,
    viewed BOOLEAN NOT NULL DEFAULT FALSE, FOREIGN KEY (userID) REFERENCES Users(id));`;

const sqlite_chat = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT, userID INTEGER NOT NULL,
    message TEXT NOT NULL, time DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    receiverID INTEGER NOT NULL, type TEXT CHECK(type IN ('private', 'group')) DEFAULT 'private',
    referenceID INTEGER, viewed INTEGER NOT NULL DEFAULT 0, FOREIGN KEY (userID) REFERENCES Users(id));`;

const postgres_chat = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Chats (
    id SERIAL PRIMARY KEY, userID INTEGER NOT NULL, message TEXT NOT NULL,
    time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, receiverID INTEGER NOT NULL,
    type TEXT CHECK(type IN ('private', 'group')) DEFAULT 'private', referenceID INTEGER,
    viewed BOOLEAN NOT NULL DEFAULT FALSE, FOREIGN KEY (userID) REFERENCES Users(id));`;



const mysql_groups = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Groups (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, ownerID INT UNSIGNED NOT NULL,
    name CHAR(20) NOT NULL, category CHAR(20) NOT NULL, description CHAR(100) NOT NULL,
    FOREIGN KEY (ownerID) REFERENCES Users(id))`;

const sqlite_groups = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT, ownerID INTEGER NOT NULL,
    name TEXT NOT NULL, category TEXT NOT NULL, description TEXT NOT NULL,
    FOREIGN KEY (ownerID) REFERENCES Users(id)
);`;

const postgres_groups = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.Groups (
    id SERIAL PRIMARY KEY, ownerID INTEGER NOT NULL, name VARCHAR(20) NOT NULL,
    category VARCHAR(20) NOT NULL, description VARCHAR(100) NOT NULL,
    FOREIGN KEY (ownerID) REFERENCES Users(id));`;



const mysql_group_members = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.GroupMembers (
    groupID INT UNSIGNED NOT NULL, userID INT UNSIGNED NOT NULL, FOREIGN KEY (groupID) REFERENCES Groups(id),
    FOREIGN KEY (userID) REFERENCES Users(id))`;

const sqlite_group_members = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.GroupMembers (
    groupID INTEGER NOT NULL, userID INTEGER NOT NULL, FOREIGN KEY (groupID) REFERENCES Groups(id),
    FOREIGN KEY (userID) REFERENCES Users(id));`;

const postgres_group_members = `CREATE TABLE IF NOT EXISTS ${process.env.CHAT_DB_NAME}.GroupMembers (
    groupID INTEGER NOT NULL, userID INTEGER NOT NULL,
    FOREIGN KEY (groupID) REFERENCES Groups(id), FOREIGN KEY (userID) REFERENCES Users(id));`;

export default class ChatTables extends Table{
    setTables(): string[] {
        switch(process.env.DB){
            case "mysql":
                return [mysql_users, mysql_chat, mysql_groups, mysql_group_members];
            case "postgres":
                return [postgres_users, postgres_chat, postgres_groups, postgres_group_members];
            default:
                return [sqlite_users, sqlite_chat, sqlite_groups, sqlite_group_members];
        }
    }
}