import AcademiaTables from "./academia";
import BlimitedTables from "./blimited";
import ChatTables from "./chat";
import GistTables from "./gist";

export { AcademiaTables, GistTables, BlimitedTables, ChatTables }