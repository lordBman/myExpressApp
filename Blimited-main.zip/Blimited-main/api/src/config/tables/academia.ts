import { Table } from "./base";

const mysql_school = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Schools (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    userID INT UNSIGNED NOT NULL,
    name CHAR(50) NOT NULL, branch CHAR(20) NOT NULL,
    motto CHAR(100) NOT NULL, address TEXT NOT NULL,
    phone CHAR(20) NOT NULL, email CHAR(50) NOT NULL);`;

const sqlite_school = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Schools (
    id INTEGER PRIMARY KEY AUTOINCREMENT, userID INTEGER NOT NULL,
    name TEXT NOT NULL, branch TEXT NOT NULL, motto TEXT NOT NULL,
    address TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL);`;

const postgres_school = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Schools (
    id SERIAL PRIMARY KEY, userID INTEGER NOT NULL, name VARCHAR(50) NOT NULL,
    branch VARCHAR(20) NOT NULL, motto VARCHAR(100) NOT NULL, address TEXT NOT NULL,
    phone VARCHAR(20) NOT NULL, email VARCHAR(50) NOT NULL);`;



const mysql_users = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Users (
    id INT UNSIGNED PRIMARY KEY,
    title ENUM('admin', 'teacher', 'student') DEFAULT 'admin', 
    schoolID INT UNSIGNED NOT NULL,
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const sqlite_users = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Users (
    id INTEGER PRIMARY KEY,
    title TEXT CHECK(title IN ('admin', 'teacher', 'student')) DEFAULT 'admin',
    schoolID INTEGER NOT NULL,
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const postgres_users = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Users (
    id SERIAL PRIMARY KEY,
    title TEXT CHECK(title IN ('admin', 'teacher', 'student')) DEFAULT 'admin',
    schoolID INTEGER NOT NULL,
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;



const mysql_subscriptions = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Subscriptions (
    id INT UNSIGNED AUTO_INCREMENT, schoolID INT UNSIGNED NOT NULL,
    status ENUM('active', 'paused', 'expired') DEFAULT 'active',
    subscribed TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    months INT UNSIGNED NOT NULL, start TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    remaining INT UNSIGNED NOT NULL, PRIMARY KEY (id, schoolID),
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const sqlite_subscriptions = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Subscriptions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, schoolID INTEGER NOT NULL,
    status TEXT CHECK(status IN ('active', 'paused', 'expired')) DEFAULT 'active',
    subscribed DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, months INTEGER NOT NULL,
    start DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, remaining INTEGER NOT NULL,
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const postgres_subscriptions = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Subscriptions (
    id SERIAL PRIMARY KEY, schoolID INTEGER NOT NULL,
    status TEXT CHECK(status IN ('active', 'paused', 'expired')) DEFAULT 'active',
    subscribed TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    months INTEGER NOT NULL, start TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    remaining INTEGER NOT NULL, FOREIGN KEY (schoolID) REFERENCES Schools(id));`;



const mysql_teachers = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Teachers (
    userID INT UNSIGNED, schoolID INT UNSIGNED, joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gender ENUM("male", "female") NOT NULL, university CHAR(20) NOT NULL, qualification CHAR(50) NOT NULL,
    graduation DATE NOT NULL, contract ENUM("full", "part", "corper"), FOREIGN KEY (userID) REFERENCES Users(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id)
)`;

const sqlite_teachers = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Teachers (
    userID INTEGER, schoolID INTEGER, joined DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gender TEXT CHECK(gender IN ('male', 'female')) NOT NULL, university TEXT NOT NULL,
    qualification TEXT NOT NULL, graduation DATE NOT NULL, contract TEXT CHECK(contract IN ('full', 'part', 'corper')),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (schoolID) REFERENCES Schools(id)
);`;

const postgres_teachers = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Teachers (
    userID INTEGER, schoolID INTEGER, joined TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    gender TEXT CHECK(gender IN ('male', 'female')) NOT NULL,  university VARCHAR(20) NOT NULL,
    qualification VARCHAR(50) NOT NULL, graduation DATE NOT NULL,
    contract TEXT CHECK(contract IN ('full', 'part', 'corper')),
    FOREIGN KEY (userID) REFERENCES Users(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id)
);`;



const mysql_sections = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Sections (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, schoolID INT UNSIGNED,
    name CHAR(50) NOT NULL,  FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const sqlite_sections = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Sections (
    id INTEGER PRIMARY KEY AUTOINCREMENT, schoolID INTEGER,
    name TEXT NOT NULL, FOREIGN KEY (schoolID) REFERENCES Schools(id)
);`;

const postgres_sections = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Sections (
    id SERIAL PRIMARY KEY, schoolID INTEGER, name VARCHAR(50) NOT NULL,
    FOREIGN KEY (schoolID) REFERENCES Schools(id)
);`;



const mysql_classes = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Classes (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, schoolID INT UNSIGNED NOT NULL,
    name CHAR(20) NOT NULL, subname CHAR(20) NOT NULL, sectionID INT UNSIGNED NOT NULL,
    category CHAR(20) DEFAULT 'general',
    FOREIGN KEY (sectionID) REFERENCES Sections(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const sqlite_classes = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Classes (
    id INTEGER PRIMARY KEY AUTOINCREMENT, schoolID INTEGER NOT NULL,
    name TEXT NOT NULL, subname TEXT NOT NULL, sectionID INTEGER NOT NULL,
    category TEXT DEFAULT 'general', FOREIGN KEY (sectionID) REFERENCES Sections(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id)
);`;

const postgres_classes = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Classes (
    id SERIAL PRIMARY KEY, schoolID INTEGER NOT NULL,
    name VARCHAR(20) NOT NULL, subname VARCHAR(20) NOT NULL,
    sectionID INTEGER NOT NULL, category VARCHAR(20) DEFAULT 'general',
    FOREIGN KEY (sectionID) REFERENCES Sections(id), FOREIGN KEY (schoolID) REFERENCES Schools(id)
);`;



const mysql_students = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Students (
    userID INT UNSIGNED PRIMARY KEY, schoolID INT UNSIGNED, dob DATE NOT NULL,
    gender ENUM("male", "female") NOT NULL, address TEXT NOT NULL,
    parents_name VARCHAR(30) NOT NULL, parents_phone VARCHAR(30) NOT NULL,
    parents_email VARCHAR(30) NOT NULL, registered TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    classID INT UNSIGNED, FOREIGN KEY (userID) REFERENCES Users(id),
    FOREIGN KEY (classID) REFERENCES Classes(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const sqlite_students = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Students (
    userID INTEGER PRIMARY KEY, schoolID INTEGER, dob DATE NOT NULL,
    gender TEXT CHECK(gender IN ('male', 'female')) NOT NULL, address TEXT NOT NULL,
    parents_name VARCHAR(30) NOT NULL, parents_phone VARCHAR(30) NOT NULL,
    parents_email VARCHAR(30) NOT NULL, registered DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    classID INTEGER, FOREIGN KEY (userID) REFERENCES Users(id),
    FOREIGN KEY (classID) REFERENCES Classes(id), FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const postgres_students = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Students (
    userID INTEGER PRIMARY KEY, schoolID INTEGER, dob DATE NOT NULL,
    gender TEXT CHECK(gender IN ('male', 'female')) NOT NULL, address TEXT NOT NULL,
    parents_name VARCHAR(30) NOT NULL, parents_phone VARCHAR(30) NOT NULL,
    parents_email VARCHAR(30) NOT NULL,  registered TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    classID INTEGER, FOREIGN KEY (userID) REFERENCES Users(id),
    FOREIGN KEY (classID) REFERENCES Classes(id), FOREIGN KEY (schoolID) REFERENCES Schools(id));`;



const mysql_subjects = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Subjects (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY, schoolID INT UNSIGNED,
    name CHAR(20) NOT NULL, sectionID INT UNSIGNED NOT NULL,
    category CHAR(20) DEFAULT 'general', FOREIGN KEY (sectionID) REFERENCES Sections(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id))`;

const sqlite_subjects = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Subjects (
    id INTEGER PRIMARY KEY AUTOINCREMENT, schoolID INTEGER,
    name TEXT NOT NULL, sectionID INTEGER NOT NULL,
    category TEXT DEFAULT 'general', FOREIGN KEY (sectionID) REFERENCES Sections(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;

const postgres_subjects = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.Subjects (
    id SERIAL PRIMARY KEY, schoolID INTEGER, name VARCHAR(20) NOT NULL,
    sectionID INTEGER NOT NULL, category VARCHAR(20) DEFAULT 'general',
    FOREIGN KEY (sectionID) REFERENCES Sections(id),
    FOREIGN KEY (schoolID) REFERENCES Schools(id));`;



const mysql_teachers_subjects = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.TeacherSubjects (
    userID INT UNSIGNED, subjectID INT UNSIGNED, schoolID INT UNSIGNED,
    PRIMARY KEY (userID, subjectID), FOREIGN KEY (schoolID) REFERENCES Schools(id),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (subjectID) REFERENCES Subjects(id))`;

const sqlite_teachers_subjects = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.TeacherSubjects (
    userID INTEGER, subjectID INTEGER, schoolID INTEGER,
    PRIMARY KEY (userID, subjectID), FOREIGN KEY (schoolID) REFERENCES Schools(id),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (subjectID) REFERENCES Subjects(id));`;

const postgres_teachers_subjects = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.TeacherSubjects (
    userID INTEGER, subjectID INTEGER, schoolID INTEGER,
    PRIMARY KEY (userID, subjectID), FOREIGN KEY (schoolID) REFERENCES Schools(id),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (subjectID) REFERENCES Subjects(id));`;


const mysql_teachers_classes = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.TeacherClasses (
    userID INT UNSIGNED, classID INT UNSIGNED, schoolID INT UNSIGNED,
    PRIMARY KEY (userID, classID), FOREIGN KEY (schoolID) REFERENCES Schools(id),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (classID) REFERENCES Classes(id));`;

const sqlite_teachers_classes = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.TeacherClasses (
    userID INTEGER, classID INTEGER, schoolID INTEGER,
    PRIMARY KEY (userID, classID), FOREIGN KEY (schoolID) REFERENCES Schools(id),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (classID) REFERENCES Classes(id));`;

const postgres_teachers_classes = `CREATE TABLE IF NOT EXISTS ${process.env.ACADAMIA_DB_NAME}.TeacherClasses (
    userID INTEGER, classID INTEGER, schoolID INTEGER,
    PRIMARY KEY (userID, classID), FOREIGN KEY (schoolID) REFERENCES Schools(id),
    FOREIGN KEY (userID) REFERENCES Users(id), FOREIGN KEY (classID) REFERENCES Classes(id));`;


export default class AcademiaTablesTable extends Table{
    setTables(): string[] {
        switch(process.env.DB){
                case "mysql":
                    return [
                        mysql_school, mysql_users, mysql_subscriptions, mysql_teachers,
                        mysql_sections, mysql_classes, mysql_students, mysql_subjects, 
                        mysql_teachers_subjects, mysql_teachers_classes ];
                case "postgres":
                    return [
                        postgres_users, postgres_users, postgres_subscriptions, postgres_teachers,
                        postgres_sections, postgres_classes, postgres_students, postgres_subjects,
                        postgres_teachers_subjects, postgres_teachers_classes ];
                default:
                    return [
                        sqlite_school, sqlite_users, sqlite_subscriptions,
                        sqlite_teachers, sqlite_sections, sqlite_classes, 
                        sqlite_students, sqlite_subjects, sqlite_teachers, sqlite_teachers_subjects, sqlite_teachers_classes ]
            }
    }
}