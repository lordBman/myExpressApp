import { Table } from "./base";

const mysql_users = `CREATE TABLE IF NOT EXISTS Users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) NOT NULL, name VARCHAR(30) NOT NULL, 
    surname VARCHAR(30) NOT NULL,  email VARCHAR(50) NOT NULL,
    phone VARCHAR(50) NOT NULL, password CHAR(50) NOT NULL,
    type CHAR(20)  NOT NULL DEFAULT 'visitor');`;

const sqlite_users = `CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL, name TEXT NOT NULL,
    surname TEXT NOT NULL, email TEXT NOT NULL,
    phone TEXT NOT NULL, password TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'visitor');`;

const postgres_users = `CREATE TABLE IF NOT EXISTS Users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL, name TEXT NOT NULL, surname TEXT NOT NULL,
    email TEXT NOT NULL, phone TEXT NOT NULL, password TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'visitor');`;



const mysql_sessions = `CREATE TABLE IF NOT EXISTS Sessions (
    id CHAR(50) NOT NULL PRIMARY KEY, userID INT UNSIGNED NOT NULL,
    platform CHAR(20) NOT NULL DEFAULT 'blimited',
    FOREIGN KEY (userID) REFERENCES Users(id));`;

const sqlite_sessions = `CREATE TABLE IF NOT EXISTS Sessions (
    id TEXT NOT NULL PRIMARY KEY, userID INTEGER NOT NULL,
    platform TEXT NOT NULL DEFAULT 'blimited',
    FOREIGN KEY (userID) REFERENCES Users(id));`;

const postgres_sessions = `CREATE TABLE IF NOT EXISTS Sessions (
    id VARCHAR(50) NOT NULL PRIMARY KEY, userID INTEGER NOT NULL,
    platform VARCHAR(20) NOT NULL DEFAULT 'blimited',
    FOREIGN KEY (userID) REFERENCES Users(id));`;


export default class BlimitedTables extends Table{
    setTables(): string[] {
        switch(process.env.DB){
            case "mysql":
                return [mysql_users, mysql_sessions];
            case "postgres":
                return [postgres_users, postgres_sessions];
            default:
                return [sqlite_users, sqlite_sessions];
        }
    }
}