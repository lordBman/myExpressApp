import express from "express";
import { User } from "../../blimited/models";
import Session from "../../config/session";
import { DBManager } from "../../config/database";

const academiaUserRouter = express.Router();

academiaUserRouter.get("/", async(req, res) =>{
    if(req.cookies.academia){
        const userID = await new Session().get(req.cookies.academia, "academia");
        if(userID){
            let details = await User.details(userID);
            if(details){
                return res.status(200).send({ id: req.cookies.academia, ...details });
            }else{
                return res.status(404).send({ message: "account not found" });
            }
        }
        return DBManager.instance().errorHandler.display(res);
    }else{
        return res.status(500).send({message: "cookie expired, try login in again"});
    }
});

export default academiaUserRouter;