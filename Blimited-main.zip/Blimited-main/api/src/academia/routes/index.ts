import express from "express";
import academiaClassesRouter from "./classes";
import { School, Section, Student, Teacher } from "../models";
import Session from "../../config/session";
import { DBManager } from "../../config/database";
import { Subscription } from "../models/subscription";
import { AcademiaUser } from "../models/user";
import academiaUserRouter from "./users";
import academiaStudentsRouter from "./students";
import academiaTeachersRouter from "./teachers";
import academiaSectionsRouter from "./sections";
import academiSubjectsRouter from "./subjects";
const academiaRouter = express.Router();

academiaRouter.use("/user", academiaUserRouter);
academiaRouter.use("/subjects", academiSubjectsRouter);
academiaRouter.use("/sections", academiaSectionsRouter);
academiaRouter.use("/teachers", academiaTeachersRouter);
academiaRouter.use("/classes", academiaClassesRouter);
academiaRouter.use("/students", academiaStudentsRouter);

academiaRouter.get("/logout", (req, res) =>{
    if(req.cookies.academia){
        res.cookie('academia', '', {
            expires: new Date(Date.now() + 10 * 300),
            httpOnly: true,
          });
          res.status(200).json({ status: 'success' });
    }else{
        return res.status(500).send({message: "invalid request to server"});
    }
});

academiaRouter.get("/", async(req, res) =>{
    if(req.cookies.academia){
        const userID = await new Session().get(req.cookies.academia, "academia");
        if(userID){
            const init = await AcademiaUser.details(userID);
            if(init){
                return res.status(200).send(init);
            }
        }
        return DBManager.instance().errorHandler.display(res);
    }else{
        return res.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaRouter.post("/school", async (req, res) =>{
    if(req.cookies.academia){
        if(req.body.name && req.body.branch && req.body.motto && req.body.address && req.body.email && req.body.phone){
            let userID = await new Session().get(req.cookies.academia, "academia");
            if(await School.check_shool(req.body.name,req.body.branch)){
                return res.status(500).send({ message: "school with the same name and branch already exists"});
            }else if(userID){
                let result = await School.create(userID, req.body.name, req.body.branch, req.body.motto, req.body.address, req.body.email, req.body.phone);
                if(result){
                    return res.status(201).send({message: "school registration succeeded" });
                }
            }
            return DBManager.instance().errorHandler.display(res);
        }else{
            return res.status(500).send({message: "invalid request to server"});
        }
    }else{
        return res.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaRouter.get("/states", async (req, res) =>{
    let schoolCount = await School.count();
    let teacherCount = await Teacher.count();
    let studentCount = await Student.count();

    let init = { schools: schoolCount  || 0, teachers: teacherCount || 0, students: studentCount || 0 };
    if(DBManager.instance().errorHandler.has_error()){
        return DBManager.instance().errorHandler.display(res);   
    }
    return res.status(200).send(init);
});

academiaRouter.get("/admin", async(req, res) =>{
    if(req.cookies.academia){
        let userID = await new Session().get(req.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let sections = await Section.all(schoolID);
                if(DBManager.instance().errorHandler.has_error()){
                    return DBManager.instance().errorHandler.display(res);
                }
                return res.status(200).send({sections: sections });
            }
        }
        return DBManager.instance().errorHandler.display(res);
    }else{
        return res.status(500).send({message: "cookie expired, try login in again"});
    }
});


academiaRouter.get("/subscriptions/:id/pause", (req, res) =>{
    if(req.params.id){
        new Subscription().pause(req.params.id).then(() =>{
            if(DBManager.instance().errorHandler.has_error()){
                return DBManager.instance().errorHandler.display(res);
            }
            return res.status(200).send({ message: "success" });
        });
    }else{
        return res.status(500).send({message: "invalid request to server"});
    }
});


//////////////////
/// Students   ///
//////////////////

const testResponse = 
{id : "asdf", subject: { name : "Computer Science", id : "xxx", section : "senior secondary", category: "general" } , 
    class_room:{ id: "JSS 3", section : "senior secondary", category: "general" }, 
    date :"2022-07-23 12:30:00", "duration": 90, 
    "sections":[
        { name: "Section A", type : "Objectives",  instruction : "Answer all questions", 
            "questions":[
                { id : "aa", image : "../images/alchemist.jpg", message : "A train passes a station platform in 36 seconds and a man standig on the platform in 20 seconds.if the speed of the train is 54 km/hr, what is the length of the platform ?", options : ["100km", "20km", "50km", "200km"]},
                { id : "ab", message : "Which of these computers has the ability to handle discrete and non discrete?", options : ["Digital", "Analogue", "Hybrid", "Continous"], "answer" : "" },
                { id : "ac", message : "The ________age is a pre- history period during which human beings widely used stone for tool making", "answer" : "" },
                { id : "ad", image : "../images/settings.svg", message : "The operation of the computer system is coordinated by a unit called ____"},
                { id : "ae", image : "../images/alchemist.jpg",  message : "The part of the computer that displays the result of the processed data is called ____ ", options : ["input unit", "output unit", "control unit", "arithmetic and logic unit"], "answer" : "" }, 
                { id : "af", message : "____ is the device used in sending data and information into the system", options : ["processor", "output", "input", "storage"] },
                { id : "ag", message : "Which of these computers has the ability to handle discrete and non discrete?", options : ["Digital", "Analogue", "Hybrid", "Continous"]},
                { id : "ah", message : "The ________age is a pre- history period during which human beings widely used stone for tool making", options : ["stone", "middle", "industral", "iron"], "answer" : "" },
                { id : "ai", message : "The operation of the computer system is coordinated by a unit called ____", options : ["memery unit", "processing unit", "storage unit", "arithmetic and logic unit"]},
                { id : "aj", message : "The part of the computer that displays the result of the processed data is called ____ ", options : ["input unit", "output unit", "control unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "ak", message : "____ is the device used in sending data and information into the system", options : ["processor", "output", "input", "storage"], "answer" : "" },
                { id : "al", message : "Which of these computers has the ability to handle discrete and non discrete?", options : ["Digital", "Analogue", "Hybrid", "Continous"], "answer" : "" },
                { id : "am", message : "The ________age is a pre- history period during which human beings widely used stone for tool making", options : ["stone", "middle", "industral", "iron"], "answer" : "" },
                { id : "an", message : "The operation of the computer system is coordinated by a unit called ____", options : ["memery unit", "processing unit", "storage unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "ao", message : "The part of the computer that displays the result of the processed data is called ____ ",  options : ["Digital", "Analogue", "Hybrid", "Continous"], "answer" : "" },
                { id : "ap", message : "The ________age is a pre- history period during which human beings widely used stone for tool making", options : ["stone", "middle", "industral", "iron"], "answer" : "" },
                { id : "aq", message : "The operation of the computer system is coordinated by a unit called ____", options : ["memery unit", "processing unit", "storage unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "an", message : "The part of the computer that displays the result of the processed data is called ____ ", options : ["input unit", "output unit", "control unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "ao", message : "____ is the device used in sending data and information into the system", options : ["processor", "output", "input", "storage"], "answer" : "" },
                { id : "ap", message : "A Bicycle passes a station platform in 36 seconds and a man standig on the platform in 20 seconds.if the speed of the train is 54 km/hr, what is the length of the platform ?", options : ["100km", "20km", "50km", "200km"], "answer" : "" }
            ]
        },
        { name: "Section B", type : "Theory", instruction : "Answer any 5 questions and number 10", 
            "questions":[
                { id : "aq", message : "A train passes a station platform in 36 seconds and a man standig on the platform in 20 seconds.if the speed of the train is 54 km/hr, what is the length of the platform ?", options : ["100km", "20km", "50km", "200km"], "answer" : "" },
                { id : "ar", message : "Which of these computers has the ability to handle discrete and non discrete?",options : ["Digital", "Analogue", "Hybrid", "Continous"], "answer" : "" },
                { id : "as", message : "The ________age is a pre- history period during which human beings widely used stone for tool making", "answer" : "" },
                { id : "at", message : "The operation of the computer system is coordinated by a unit called ____", options : ["memery unit", "processing unit", "storage unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "au", message : "The part of the computer that displays the result of the processed data is called ____ ", options : ["input unit", "output unit", "control unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "av", message : "____ is the device used in sending data and information into the system", options : ["processor", "output", "input", "storage"], "answer" : "" },
                { id : "aw", message : "Which of these computers has the ability to handle discrete and non discrete?", options : ["Digital", "Analogue", "Hybrid", "Continous"], "answer" : "" },
                { id : "ax", message : "The ________age is a pre- history period during which human beings widely used stone for tool making", options : ["stone", "middle", "industral", "iron"], "answer" : "" },
                { id : "ay", message : "The operation of the computer system is coordinated by a unit called ____", options : ["memery unit", "processing unit", "storage unit", "arithmetic and logic unit"], "answer" : "" },
                { id : "az", message : "Kindly pick out the odd ones from the list.",
                    options : [
                        {id:"ba", message : "Laptop Companies", "answer" : "" , options :["Lenovo", "Hawad packard", "Asus", "Acer"]}, 
                        {id:"bb", message : "Smart Phone Companies", "answer" : "", options :["Tecno", "Samsung", "Itel", "Nokia"]},
                        {id:"bc", message : "JRPG Games", "answer" : "", options :["Final Fantasy", "Counter Strike", "Chrono Trigger", "Dissidia"]}
                    ]
                },
                { id : "a1", message : "The part of the computer that displays the result of the processed data is called ____ ", options : ["input unit", "output unit", "control unit", "arithmetic and logic unit"], "answer" : "" }
            ]
        }
    ]
};

academiaRouter.get("/exam/student/login", (request, response) =>{
    return response.status(200).send(testResponse);
});

export default academiaRouter;