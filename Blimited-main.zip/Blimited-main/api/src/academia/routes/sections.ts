import express from "express";
import Section from "../models/section";
import Session from "../../config/session";
import { AcademiaUser } from "../models";
import { DBManager } from "../../config/database";

const academiaSectionsRouter = express.Router();

academiaSectionsRouter.post("/", async (req, res) =>{
    if(req.cookies.academia){
        if(req.body.sections){console.log(req.body.sections);
            let userID = await new Session().get(req.cookies.academia, "academia");
            if(userID){
                let schoolID = await AcademiaUser.schoolID(userID);
                if(schoolID){
                    let index = 0;
                    let init: {id: string, name: string}[] = [];
                    for(let index = 0; index < req.body.sections.length; index++){
                        let result = await Section.create(schoolID, req.body.sections[index]);
                        if(result){
                            init.push({id: result.toString(), name: req.body.sections[index]});
                        }else{
                            break;
                        }
                    }  
                    return res.status(201).send({message: "sections registration succeeded", sections: init });    
                }
            }
            return DBManager.instance().errorHandler.display(res);
        }else{
            return res.status(500).send({message: "invalid request to server"});
        }
    }else{
        return res.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaSectionsRouter.get("/", async (request, response) =>{
    if(request.cookies.academia){
        let userID = await new Session().get(request.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let init = await Section.all(schoolID);
                if(!DBManager.instance().errorHandler.has_error()){
                    return response.status(200).send(init);
                }
            }
        }
        return DBManager.instance().errorHandler.display(response);
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaSectionsRouter.get("/:id", async(request, response) =>{
    if(request.cookies.academia){
        let userID = await new Session().get(request.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let init = await Section.get(schoolID, request.params.id);
                if(init){
                    return response.status(200).send(init);
                }
            }
        }
        return DBManager.instance().errorHandler.display(response);
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

export default academiaSectionsRouter;