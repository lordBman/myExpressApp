import express from "express";
import { AcademiaUser, Subject } from "../models";
import Session from "../../config/session";
import { DBManager } from "../../config/database";

const academiSubjectsRouter = express.Router();

academiSubjectsRouter.post("/", async(request, response) =>{
    if(request.cookies.academia){
        if(request.body.schoolID && request.body.name && request.body.section){
            let init = await Subject.create(request.body.schoolID, request.body.name, request.body.section, request.body.category);
            if(init){
                return response.status(201).send({message: "subject creation success", subjectID: init });
            }
            return DBManager.instance().errorHandler.display(response);
        }else{
            return response.status(500).send({message: "invalid request to server"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiSubjectsRouter.get("/:id", async(request, response) =>{
    if(request.cookies.academia){
        let userID = await new Session().get(request.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let init = await Subject.details(schoolID, request.params.id);
                if(init){
                    return response.status(200).send(init);
                }
                return DBManager.instance().errorHandler.display(response);
            }else{
                return response.status(500).send({message: "server error, make sure your account is associated with a school account"});
            }
        }else{
            return response.status(500).send({message: "session error, unable to fetch user id"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

export default academiSubjectsRouter;