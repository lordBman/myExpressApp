import express, { Response } from "express";
import Session from "../../config/session";
import { AcademiaUser } from "../models/user";
import { DBManager } from "../../config/database";
import { ClassRoom } from "../models";

const academiaClassesRouter = express.Router();

academiaClassesRouter.post("/", (request, response) =>{
    if(request.cookies.academia){
        if(request.body.schoolID && request.body.name && request.body.section){           
            ClassRoom.create(request.body.schoolID, request.body.name, request.body.section, request.body.category).then((subjectID)=>{
                if(subjectID){
                    return response.status(201).send({message: "class creation success", id: subjectID });
                }
                return DBManager.instance().errorHandler.display(response);
            });
        
        }else{
            return response.status(500).send({message: "invalid request to server"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaClassesRouter.get("/:id", async(request, response) =>{
    if(request.cookies.academia){
        let userID = await new Session().get(request.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let init =  ClassRoom.details(schoolID, request.params.id);
                if(init){
                    return response.status(201).send(init);
                }
                return DBManager.instance().errorHandler.display(response);
            }else{
                return response.status(500).send({message: "server error, make sure your account is associated with a school account"});
            }
        }else{
            return response.status(500).send({message: "session error, unable to fetch user id"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

export default academiaClassesRouter;