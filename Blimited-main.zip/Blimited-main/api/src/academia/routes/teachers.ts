import express from "express";
import { AcademiaUser, Teacher } from "../models";
import { DBManager } from "../../config/database";
import Session from "../../config/session";

const academiaTeachersRouter = express.Router();

academiaTeachersRouter.post("/", async(request, response) =>{
    if(request.cookies.academia){
        if(request.body.schoolID && request.body.gender && request.body.university && request.body.graduation && request.body.qualification && request.body.contract && request.body.teacherDetails){
            let userID = await Teacher.create(request.body.schoolID, request.body.gender, request.body.university, request.body.graduation, request.body.qualification, request.body.contract, request.body.teacherDetails);
            if(userID){
                return response.status(201).send({message: "teacher registration success" });
            }
            return DBManager.instance().errorHandler.display(response);
        
        }else{
            return response.status(500).send({message: "invalid request to server"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaTeachersRouter.get("/", async(request, response) =>{
    if(request.cookies.academia){
        let userID = await new Session().get(request.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let init = await Teacher.all(schoolID);
                if(init){
                    return response.status(200).send(init);
                }
                return DBManager.instance().errorHandler.display(response);
            }else{
                return response.status(500).send({message: "server error, make sure your account is associated with a school account"});
            }
        }else{
            return response.status(500).send({message: "session error, unable to fetch user id"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

academiaTeachersRouter.get("/:id", async(request, response) =>{
    if(request.cookies.academia){
        let userID = await new Session().get(request.cookies.academia, "academia");
        if(userID){
            let schoolID = await AcademiaUser.schoolID(userID);
            if(schoolID){
                let init =  await Teacher.details(request.params.id, schoolID);
                if(init){
                    return response.status(200).send(init);
                }
                return DBManager.instance().errorHandler.display(response);
            }else{
                return response.status(500).send({message: "server error, make sure your account is associated with a school account"});
            }
        }else{
            return response.status(500).send({message: "session error, unable to fetch user id"});
        }
    }else{
        return response.status(500).send({message: "cookie expired, try login in again"});
    }
});

export default academiaTeachersRouter;
