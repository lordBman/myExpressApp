import { DBManager } from "../../config/database";
import Section from "./section";

export interface ClassRoomDetails{
    id: string, name: string, category: string
}

export default class ClassRoom{
    static async check_classes(schoolID:  string, name: string, sectionID: string): Promise<boolean|undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Classes WHERE name = ? AND sectionID = ? AND schoolID = ?`, [name,  sectionID, schoolID], "classes checking error");
        if(typeof rows !== "undefined"){
            return rows.length > 0;
        }
        return undefined;
    }

    static async create(schoolID: string, name: string, section: string, category?:string): Promise<number | undefined>{
        let sectionID = await Section.create(schoolID, section);
        if(sectionID){
            return await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Classes(schoolID, name, sectionID, category) VALUES(?, ?, ?, ?);`, [schoolID, name, sectionID, category || "general"], "class creation error");
        }
        return undefined;
    }

    static async details(schoolID:  string, id: string): Promise<ClassRoomDetails | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Classes WHERE schoolID = ? AND id = ?`, [schoolID, id], "Error encountered when getting class room details");
        if(rows && rows.length > 0){
            let section = await Section.get_name(schoolID, rows[0].sectionID);
            if(section){
                return  { id: rows[0].id, name: rows[0].name, category: rows[0].category };
            }
        }else if(rows && rows.length <= 0){
            DBManager.instance().errorHandler.add(404, "", "class not found");
        }
        return undefined;
    }

    static async all(schoolID: string, sectionID: string): Promise<ClassRoomDetails[] | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Classes WHERE schoolID = ? AND sectionID = ?`, [schoolID, sectionID], "Error encountered when getting class room details");
        if(init){
            let classes: ClassRoomDetails[] = [];
            init.forEach((row)=>{
                classes.push({ id: row.id, name: row.name, category: row.category });
            });
            return classes;
        }
        return undefined;
    }
}