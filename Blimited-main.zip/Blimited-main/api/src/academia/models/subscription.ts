import { DBManager } from "../../config/database";

export interface SubscriptionDetails{
    id: number, status: string, subscribed: string, months: number,
    start: string, remaining: number, isExpired: boolean
}

const AddMinutesToDate = (date: Date, periodInMinutes: number): Date =>{
    let milliseconds = date.valueOf();
    return new Date(milliseconds + periodInMinutes * 1000 * 60);
}

const DateToMinutes = (date: Date): number =>{
    let milliseconds = date.valueOf();
    return Math.floor((milliseconds / 1000) / 60);
}

const DateMinusDateInMinutes = (dateA: Date, dateB: Date) =>{
    let milliseconds = dateA.valueOf() - dateB.valueOf();
    return Math.floor((milliseconds / 1000) / 60);
}

const MonthsToMinutes = (months: number)=> months * 30 * 24 * 60;

export class Subscription{
    async check_subs(schoolID: string): Promise<boolean | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Subscriptions WHERE schoolID = ?`, [schoolID], "subscriptions checking error");
        if(rows!.length >= 0){
            return rows!.length > 0;
        }
        return undefined;
    }

    async is_expired(id: string): Promise<boolean | undefined>{
        try{
            const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Subscriptions WHERE id = ?`, [id], "subscriptions checking error");
            if(rows && rows.length > 0){
                let start = new Date(rows[0].start as string);
                let remaining = Number.parseFloat(rows[0].remaining);
                
                let expected = AddMinutesToDate(start, remaining);
                let current = Date.now();

                return expected.valueOf() < current.valueOf();
            }
        }catch(ex: any){
            console.log(ex);
            DBManager.instance().errorHandler.add(500, ex, "server encounterd error while calulating subscription");
        }
        return undefined;
    }

    async pause(id: string): Promise<boolean | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Subscriptions WHERE id = ?`, [id], "subscriptions checking error");
        if(rows && rows.length > 0){
            let initstart = new Date(rows[0].start as string);
            let remaining = rows[0].remaining as number;

            let expected = AddMinutesToDate(initstart, remaining);

            let newStart = new Date();
            let newRemaininig = DateMinusDateInMinutes(expected, newStart);

            return await DBManager.instance().update(`UPDATE ${process.env.ACADAMIA_DB_NAME}.Subscriptions SET start = ?, remaining = ?, status = ? WHERE id = ?`, [newStart, newRemaininig, "paused"], "subscription pausing error");
        }
    }

    async details(schoolID: string): Promise<SubscriptionDetails | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Subscriptions WHERE schoolID = ?`, [schoolID], "Error encountered when getting subscription details");
        if(rows  && rows.length > 0){
            const isExpired = await this.is_expired(rows[0].id);
            if(isExpired !== undefined){
                return  { 
                    id: rows[0].id, status: rows[0].status, subscribed: rows[0].subscribed,
                    months: rows[0].months, start: rows[0].start, remaining: rows[0].remaining, isExpired: isExpired
                };
            }
        }
        return undefined;
    }

    async create(schoolID: number, months: number): Promise<SubscriptionDetails | undefined>{
        let remaining = MonthsToMinutes(months);

        const init = await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Subscriptions(schoolID, months, remaining) VALUES(?, ?, ?)`, [ schoolID, months, remaining], "subcription creation error");
        if(init){
            return this.details(init.toString());
        }
        return undefined;
    }
}