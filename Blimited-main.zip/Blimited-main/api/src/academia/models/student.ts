import User, { UserDetails } from "../../blimited/models/user";
import ClassRoom, { ClassRoomDetails } from "./classes";
import { AcademiaUser } from "./user";
import { DBManager } from "../../config/database";

export interface StudentDetails{
    details: UserDetails,  dob: string, gender: string,
    address: string, parent_name: string, parent_phone: string, parent_email: string,
    registered: string, classRoom: ClassRoomDetails
}

export default class Student{
    static async check_students(schoolID: string, userID: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Students WHERE schoolID = ? AND userID = ?`, [schoolID, userID], "students checking error");
        if(init){
            const rows = init as any[];
            return rows.length > 0;
        }
        return undefined;
    }

    static async details(studentID: string, schoolID: string): Promise<StudentDetails| undefined>{
        const studentDetails = await User.details(studentID);
        if(studentDetails){
            const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Students WHERE schoolID = ? AND userID = ?`, [schoolID, studentID], "Error encountered when getting student details");
            if(init && (init as any[]).length > 0){
                const rows = init as any[];
                let classRoom = await ClassRoom.details(schoolID, rows[0].id);
                if(classRoom){
                    return { 
                        details: studentDetails,  dob: rows[0].dob, gender: rows[0].gender,
                        address: rows[0].address, parent_name: rows[0].parent_name, parent_phone: rows[0].parent_phone,
                        parent_email: rows[0].parent_email,  registered: rows[0].registered, classRoom
                    };
                }
            }else if(init && (init as any[]).length <= 0){
                DBManager.instance().errorHandler.add(404, "", "student not found");
            }
        }
        return undefined;
    }

    static async count(): Promise<number | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Students`, [], "Error encountered when getting school count");
        if(init && (init as any[]).length > 0){
            return (init as any[]).length;
        }
        return undefined;
    }

    static async all(schoolID: string): Promise<StudentDetails[]| undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Students WHERE schoolID = ?`, [schoolID], "Error encountered when getting teacher details");
        if(init){
            const students: StudentDetails[] = [];

            if((init as any[]).length > 0){
                const rows = init as any[];
                for(let i = 0; i < rows.length; i++){
                    const row = rows[i];

                    const studentDetails = await User.details(row.userID);
                    const classRoom = await ClassRoom.details(schoolID, row.id);
                    if(studentDetails && classRoom){
                        students.push({ 
                            details: studentDetails,  dob: row.dob, gender: row.gender,
                            address: row.address, parent_name: row.parent_name, parent_phone: row.parent_phone,
                            parent_email: row.parent_email,  registered: row.registered, classRoom
                        });
                    }else{
                        return undefined;
                    }
                }
            }
            return students;
        }
        return undefined;
    }

    static async create(schoolID: string, dob: string, gender: string, address: string, parent_name: string,
        parent_phone: string, parent_email: string, classID: string, studentDetails: {fname?: string, email: string, phone: string }): Promise<boolean | undefined>{
        
            let studentID: number | undefined;

            if(studentDetails.fname && studentDetails.email && studentDetails.phone) {
                let password = studentDetails.phone || parent_phone;
                studentID = await User.create(studentDetails.fname, `${studentDetails.fname.toLowerCase().replace(" ", "_")}`, studentDetails.email, studentDetails.phone, password, "academia");
            }else if(studentDetails.email && studentDetails.phone){
                studentID = await User.get_id({ email: studentDetails.email, phone: studentDetails.phone });
            }
            
            if(studentID && await this.check_students(schoolID, studentID.toString())){
                DBManager.instance().errorHandler.add(500, "", "teacher with the same ID already exist");
            }else if(studentID){
                const init = await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Students(schoolID, userID, dob, gender, address, parent_name, parent_phone, parent_email) VALUES(?, ?, ?, ?, ?, ?, ?, ?)`, [schoolID, studentID, dob, gender, address, address, parent_name, parent_phone, parent_email], "Error encountered registering teacher");
                if(init){
                    return  AcademiaUser.create(studentID.toString(), Number.parseInt(schoolID), "students");
                }
            }
        return undefined;
    }
}
