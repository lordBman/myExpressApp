import { Subscription, SubscriptionDetails } from "./subscription";
import { DBManager } from "../../config/database";
import { AcademiaUser } from "./user";

export interface SchoolDetails{
    id: string, name: string, branch: string, motto: string, address: string, phone: string,
    email: string, subscription?: SubscriptionDetails
}

export default class School{
    static async check_shool(name: string, branch: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Schools WHERE name = ? AND branch = ?`, [name, branch], "schools checking error");
        if(init){
            const rows = init as any[];
            return rows.length > 0;
        }
        return undefined;
    }

    static async create(userID: string, name: string, branch:string, motto: string, address: string, email: string, phone: string): Promise<boolean|undefined>{
        const init = await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Schools(userID, name, branch, motto, address, email, phone) VALUES(?, ?, ?, ?, ?, ?, ?)`,
            [userID, name, branch, motto, address, email, phone], "school registration failed");
        if(init){
            const subscription = await new Subscription().create(init, 1);
            const academia_user = await AcademiaUser.create(userID,  init, "admin");
            if(subscription && academia_user){
                return true;
            }
        }
    }

    static async details(id: string): Promise<SchoolDetails | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Schools WHERE id = ?`, [id], "Error encountered when getting school details");
        if(init && (init as any[]).length > 0){
            const rows = init as any[];
            let subcription = await new Subscription().details(id);
            return  { 
                id: rows[0].id, name: rows[0].name, branch: rows[0].branch, motto: rows[0].motto,
                phone: rows[0].phone, email: rows[0].email, address: rows[0].address, subscription: subcription
            };
        }
        return undefined;
    }

    static async count(): Promise<number | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Schools`, [], "Error encountered when getting school count");
        if(init && (init as any[]).length > 0){
            return (init as any[]).length;
        }
        return undefined;
    }
}

