import User, { UserDetails } from "../../blimited/models/user";
import School, { SchoolDetails } from "./school";
import { DBManager } from "../../config/database";

interface AcademiaUserDetails{
    user: UserDetails, title?: string, school?: SchoolDetails
}

export class AcademiaUser{
    static async check_user(id: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Users WHERE id = ?`, [id], "users checking error");
        if(init){
            const rows = init as any[];
            return rows.length > 0;
        }
        return undefined;
    }

    static async details(id: string): Promise<AcademiaUserDetails | undefined>{
        let user = await User.details(id);
        if(user){
            let details: AcademiaUserDetails = { user };
            const init = await DBManager.instance().get(`SELECT title, schoolID FROM ${process.env.ACADAMIA_DB_NAME}.Users WHERE id = ?`, [id], "user checking error");
            if(init && (init as any[]).length > 0){
                const rows = init as any[];

                let school = await School.details(rows[0].schoolID);
                let title = rows[0].title;
                if(school){
                    details = { ...details, school, title };
                }
            }
            return details;
        }
        return undefined;
    }

    static async create(userID: string, schoolID: number, title: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Users(title, id, schoolID) VALUES(?, ?, ?)`, [title, userID, schoolID], "user creation error");
        if(init){
            return true;
        }
        return undefined;
    }

    static async schoolID(userID: string): Promise<string | undefined>{
        const init = await DBManager.instance().get(`SELECT schoolID FROM ${process.env.ACADAMIA_DB_NAME}.Users WHERE id = ?`, [userID], "user checking error");
        if(init && (init as any[]).length > 0){
            const rows = init as any[];
            return rows[0].schoolID;
        }
        return undefined;
    }
}