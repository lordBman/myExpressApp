import { DBManager } from "../../config/database";
import Session from "../../config/session";
import Section from "./section";
import { AcademiaUser } from "./user";

export interface SubjectDetails{
    id: string, name: string, subname: string, category: string
}

export default class Subject{
    static async check_subjects(schoolID: string, name: string, sectionID: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Subjects WHERE schoolID = ? AND name = ? AND sectionID = ?`, [schoolID, name, sectionID], "subjects checking error");
        if(init){
            const rows = init as any[];
            return rows.length > 0;
        }
        return undefined;
    }

    static async create(schoolID: string, name: string, section: string, category?:string): Promise<number | undefined>{
        let sectionID = await Section.create(schoolID, section);
        if(sectionID){
            return await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Subjects(schoolID, name, sectionID, category) VALUES(?, ?, ?, ?)`, [schoolID, name, sectionID, category || "general"], "class creation error");
        }
        return undefined;
    }

    static async details( schoolID: string, id: string): Promise<SubjectDetails | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Schools WHERE schoolID = ? AND id = ?`, [schoolID, id], "Error encountered when getting subjects details");
        if(init && (init as any[]).length > 0){
            const rows = init as any[];
            let section = await Section.get_name(schoolID, rows[0].sectionID);
            if(section){
                return  { id: rows[0].id, name: rows[0].name, subname: rows[0].subname, category: rows[0].category };
            }
        }else if(init && (init as any[]).length <= 0){
            DBManager.instance().errorHandler.add(404, "", "subject not found");
        }
        return undefined;
    }

    static async all(schoolID: string, sectionID: string): Promise<SubjectDetails[] | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Subjects WHERE schoolID = ? AND sectionID = ? `, [schoolID, sectionID], "Error encountered when getting subjects details");
        if(init){
            const subjects: SubjectDetails[] = [];
            init.forEach((row)=>{
                subjects.push({ id: row.id, name: row.name, subname: row.subname, category: row.category });
            });
            return subjects;
        }
        return undefined;
    }
}

