import User, { UserDetails } from "../../blimited/models/user";
import  Subject, { SubjectDetails } from "./subject";
import { AcademiaUser } from "./user";
import { DBManager } from "../../config/database";
import ClassRoom, { ClassRoomDetails } from "./classes";

interface TeacherDetails{
    details : UserDetails, joined: string,
    gender: string, university: string, qualification: string, graduation: string, contract: string,
    subjects: SubjectDetails[], classes: ClassRoomDetails[]
}

export class TeacherSubjects{
    static async get_subjects(schoolID: string, teacherID: string): Promise<SubjectDetails[] | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.TeacherSubjects WHERE schoolID = ? AND userID = ?`, [schoolID, teacherID], "teacher's subjects checking error");
        if(init){
            const rows = init as any[];

            let subjects: SubjectDetails[] = [];
            for(let i = 0; i < rows.length; i++){
                const row = rows[i];

                const subject = await Subject.details(schoolID, row.subjectID);
                if(subject && !DBManager.instance().errorHandler.has_error()){
                    subjects.push(subject);
                }else if(DBManager.instance().errorHandler.has_error()){
                    return undefined;
                }
            }
            return subjects;
        }
        return undefined;
    }
}

export class TeacherClasses{
    static async get_classes(schoolID: string, teacherID: string): Promise<ClassRoomDetails[] | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.TeacherClasses WHERE schoolID = ? AND userID = ?`, [schoolID, teacherID], "teacher's subjects checking error");
        if(typeof rows !== "undefined"){
            let classes: ClassRoomDetails[] = [];
            for(let i = 0; i < rows.length; i++){
                const row = rows[i];
                const classRoom = await ClassRoom.details(schoolID, row.classID);
                if(classRoom && !DBManager.instance().errorHandler.has_error()){
                    classes.push(classRoom);
                }else if(DBManager.instance().errorHandler.has_error()){
                    return undefined;
                }
            }
            return classes;
        }
        return undefined;
    }
}

export default class Teacher{
    static async check_teachers(schoolID: string, userID: string): Promise<boolean | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Teachers WHERE schoolID = ? AND userID = ?`, [schoolID, userID], "teachers checking error");
        if(typeof rows !== "undefined"){
            return rows.length > 0;
        }
        return undefined;
    }

    static async details(teacherID: string, schoolID: string): Promise<TeacherDetails| undefined>{
        const teacherDetails = await User.details(teacherID);
        if(teacherDetails){
            const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Teachers WHERE userID = ?`, [teacherID], "Error encountered when getting teacher details");
            if(typeof rows !== "undefined" && rows.length > 0){
                let classes = await TeacherClasses.get_classes(schoolID, rows[0].id);
                let subjects = await TeacherSubjects.get_subjects(schoolID, rows[0].id);
                if(classes && subjects){
                    return { 
                        details: teacherDetails, subjects, classes, gender: rows[0].gender, 
                        joined: rows[0].joined,
                        university: rows[0].university, 
                        graduation: rows[0].graduation,
                        qualification: rows[0].qualification,
                        contract: rows[0].contract
                    };
                }
            }else if(typeof rows !== "undefined"){
                DBManager.instance().errorHandler.add(404, "", "teacher not found");
            }
        }
        return undefined;
    }

    static async count(): Promise<number | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Teachers`, [], "Error encountered when getting school count");
        if(typeof init !== "undefined"){
            return init.length;
        }
        return undefined;
    }

    static async all(schoolID: string): Promise<TeacherDetails[]| undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Teachers WHERE schoolID = ?`, [schoolID], "Error encountered when getting teacher details");
        if(typeof rows !== "undefined"){
            const teachers: TeacherDetails[] = [];
            if(rows.length > 0){
                for(let i = 0; i < rows.length; i++){
                    const row = rows[i];

                    const teacherDetails = await User.details(row.userID);
                    const classes = await TeacherClasses.get_classes(schoolID, row.id);
                    const subjects = await TeacherSubjects.get_subjects(schoolID, row.id);
                    if(teacherDetails && classes && subjects){
                        teachers.push({ 
                            details: teacherDetails, subjects, classes, gender: rows[0].gender, 
                            joined: rows[0].joined,
                            university: rows[0].university, 
                            graduation: rows[0].graduation,
                            qualification: rows[0].qualification,
                            contract: rows[0].contract
                        });
                    }else{
                        return undefined;
                    }
                }
            }
            return teachers;
        }
        return undefined;
    }

    static async create(schoolID: string, gender: string, university: string, graduation: string, qualification: string, contract: string, teacherDetails: {fname?: string, email: string, phone: string }) : Promise< boolean| undefined>{
        let teacherID: number | undefined;

        if(teacherDetails.fname && teacherDetails.email && teacherDetails.phone) {
            let password = teacherDetails.phone;
            teacherID = await User.create(teacherDetails.fname, `${teacherDetails.fname.toLowerCase().replace(" ", "_")}`, teacherDetails.email, teacherDetails.phone, password, "academia");
        }else if(teacherDetails.email && teacherDetails.phone){
            teacherID = await User.get_id({ email: teacherDetails.email, phone: teacherDetails.phone });
        }

        if(teacherID && await this.check_teachers(schoolID, teacherID.toString())){
            DBManager.instance().errorHandler.add(500, "", "teacher with the same ID already exist");
        }else if(teacherID){
            const init = await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Teachers(schoolID, userID, gender, university, graduation, qualification, contract) VALUES(?, ?, ?, ?, ?, ?, ?)`, [schoolID, teacherID, gender, university, graduation, qualification, contract], "Error encountered registering teacher");
            if(init){
                return  await AcademiaUser.create(teacherID.toString(), Number.parseInt(schoolID), "teacher");
            }
        }
        return undefined;
    }
}

