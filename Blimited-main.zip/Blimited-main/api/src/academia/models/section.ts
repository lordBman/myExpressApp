import { DBManager } from "../../config/database";
import ClassRoom, { ClassRoomDetails } from "./classes";
import Subject, { SubjectDetails } from "./subject";

export interface SectionDetails{
    name: string, id: string, classes?: ClassRoomDetails[], subjects?: SubjectDetails[]
}

export default class Section{
    static async check_sections(schoolID:string, name: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Sections WHERE schoolID = ? AND name = ?`, [schoolID, name], "sections checking error");
        if(init){
            const rows = init as any[];
            return rows.length > 0;
        }
        return undefined;
    }

    static async create(schoolID:  string, name: string): Promise<number | undefined>{
        if(await this.check_sections(schoolID, name)){
            return this.get_id(schoolID, name);
        }
        return  await DBManager.instance().insert(`INSERT INTO ${process.env.ACADAMIA_DB_NAME}.Sections(schoolID, name) VALUES(?, ?)`, [schoolID, name], "section creation error");
    }

    static async get_id(schoolID: string, name: string): Promise<number | undefined>{
        const init = await DBManager.instance().get(`SELECT id FROM ${process.env.ACADAMIA_DB_NAME}.Sections WHERE schoolID = ? AND name = ?`, [schoolID, name], "sections checking error");
        if(init){
            const rows = init as any[];
            return rows[0].id;
        }
        return undefined;
    }

    static async get_name( schoolID: string, id: string): Promise<string | undefined>{
        const init = await DBManager.instance().get(`SELECT id FROM ${process.env.ACADAMIA_DB_NAME}.Sections WHERE schoolID = ? AND id = ?`, [schoolID, id], "sections checking error");
        if(init){
            const rows = init as any[];
            return rows[0].name;
        }
        return undefined;
    }

    static async get(schoolID: string, id: string): Promise<{ id: string, name: string, classes?: ClassRoomDetails[], subjects?: SubjectDetails[] } | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Sections WHERE schoolID = ? AND id = ?`, [schoolID, id], "sections checking error");
        if(init && (init as any[])){
            const row = (init as any[])[0];
            
            const classes = await ClassRoom.all(schoolID, row.id);
            const subjects = await Subject.all(schoolID, row.id);
            if(!DBManager.instance().errorHandler.has_error()){
                return { id: id, name: row.name, classes, subjects }
            } 
        }
        return undefined;
    }

    static async all(schoolID: string): Promise<SectionDetails[] | undefined>{
        const rows = await DBManager.instance().get(`SELECT * FROM ${process.env.ACADAMIA_DB_NAME}.Sections WHERE schoolID = ?`, [schoolID], "sections checking error");
        if(rows){
            let init  = [];
            for(let i = 0; i < rows.length; i++){
                const row = rows[i];
                const classes = await ClassRoom.all(schoolID, row.id);
                const subjects = await Subject.all(schoolID, row.id);
                
                init.push({id: row.id as string, name: row.name as string, classes, subjects });
            }
            return init;
        }
        return undefined;
    }
}