import mysql from "mysql2";
import { DBManager } from "../../config/database";

class GistUser{
    async check_users(id: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().get(`SELECT * FROM ${process.env.GIST_DB_NAME}.Users WHERE id = ?`, [id], "gist users checking error");
        if(init){
            const rows = init as mysql.RowDataPacket[];
            return rows.length > 0;
        }
        return undefined;
    }

    async refresh(id: string): Promise<boolean | undefined>{
        const init = await DBManager.instance().update(`UPDATE ${process.env.GIST_DB_NAME}.Users SET last = CURRENT_TIMESTAMP WHERE id = ?`, [id], "gist user refresh error");
        if(init){
            return true;
        }
        return undefined;
    }
}

export default GistUser;