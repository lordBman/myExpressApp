import express from "express";
import Session from "../../config/session";
import { DBManager } from "../../config/database";
import { User } from "../../blimited/models";

export const gistRouter = express.Router();

gistRouter.get("/user", async(req, res) =>{
    if(req.cookies.gist){
        const userID = await new Session().get(req.cookies.gist, "gist");
        if(userID){
            let details = User.details(userID);
            if(details){
                return res.status(200).send({ id: req.cookies.gist, ...details });
            }else{
                return res.status(404).send({ message: "account not found" });
            }
        }
        return DBManager.instance().errorHandler.display(res);
    }else{
        return res.status(500).send({message: "cookie expired, try login in again"});
    }
});

gistRouter.get("/logout", (req, res) =>{
    if(req.cookies.gist){
        res.cookie('gist', '', {
            expires: new Date(Date.now() + 10 * 300),
            httpOnly: true,
          });
          res.status(200).json({ status: 'success' });
    }else{
        return res.status(500).send({message: "invalid request to server"});
    }
});